/**
 * CampusFix — Smart Campus Issue Reporting & Resolution System
 * Shared UI Helper & Component Framework
 * Institution: Bansal Institute of Engineering & Technology (BIET), Lucknow
 */

const CampusFixUI = {
  // Built-in Crisp SVG Icons for guaranteed offline/CDN-independent rendering
  icons: {
    mortarboard: `<svg class="w-5 h-5 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>`,
    shieldCheck: `<svg class="w-5 h-5 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>`,
    checkCircle: `<svg class="w-4 h-4 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
    clock: `<svg class="w-4 h-4 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
    alertCircle: `<svg class="w-4 h-4 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
    xCircle: `<svg class="w-4 h-4 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
    arrowRight: `<svg class="w-4 h-4 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>`,
    send: `<svg class="w-4 h-4 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`,
    refresh: `<svg class="w-4 h-4 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>`,
    user: `<svg class="w-4 h-4 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
    logOut: `<svg class="w-4 h-4 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>`,
    fileText: `<svg class="w-4 h-4 inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>`
  },

  // Display Toast Notification
  showToast(title, message, type = 'info', duration = 3500) {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'toast-item';

    let iconSvg = this.icons.clock;
    let iconColor = 'text-blue-600 bg-blue-50';

    if (type === 'success') {
      iconSvg = this.icons.checkCircle;
      iconColor = 'text-emerald-600 bg-emerald-50';
    } else if (type === 'error') {
      iconSvg = this.icons.xCircle;
      iconColor = 'text-red-600 bg-red-50';
    } else if (type === 'warning') {
      iconSvg = this.icons.alertCircle;
      iconColor = 'text-amber-600 bg-amber-50';
    }

    toast.innerHTML = `
      <div class="w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${iconColor}">
        ${iconSvg}
      </div>
      <div class="flex-1">
        <h4 class="text-xs font-bold text-slate-900 leading-tight">${title}</h4>
        <p class="text-xs text-slate-600 mt-0.5 leading-snug">${message}</p>
      </div>
      <button class="text-slate-400 hover:text-slate-600 text-sm font-bold leading-none shrink-0" onclick="this.parentElement.remove()">&times;</button>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.25s ease';
      setTimeout(() => toast.remove(), 250);
    }, duration);
  },

  // Render Status Badge matching reference poster specifications
  renderStatusBadge(status) {
    const s = (status || '').trim();
    switch (s) {
      case 'Submitted':
        return `<span class="badge-status badge-submitted">${this.icons.clock} Submitted</span>`;
      case 'Under Verification':
        return `<span class="badge-status badge-verification">${this.icons.clock} Under Verification</span>`;
      case 'Forwarded to Management':
        return `<span class="badge-status badge-forwarded">${this.icons.send} Forwarded</span>`;
      case 'In Progress':
        return `<span class="badge-status badge-in-progress">${this.icons.refresh} In Progress</span>`;
      case 'Resolved':
        return `<span class="badge-status badge-resolved">${this.icons.checkCircle} Resolved</span>`;
      case 'Rejected':
        return `<span class="badge-status badge-rejected">${this.icons.xCircle} Rejected</span>`;
      default:
        return `<span class="badge-status badge-submitted">${status || 'Pending'}</span>`;
    }
  },

  // Render Priority Badge
  renderPriorityBadge(priority) {
    const p = (priority || 'Medium').toLowerCase();
    if (p === 'high') {
      return `<span class="badge-status badge-priority-high font-semibold">High</span>`;
    } else if (p === 'low') {
      return `<span class="badge-status badge-priority-low font-semibold">Low</span>`;
    }
    return `<span class="badge-status badge-priority-medium font-semibold">Medium</span>`;
  },

  // Render Verification Badge (for students)
  renderStudentVerifiedBadge(isVerified) {
    if (isVerified === true || isVerified === 'Verified') {
      return `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">${this.icons.checkCircle} Verified</span>`;
    }
    return `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">${this.icons.xCircle} Not Verified</span>`;
  },

  // Render Timeline matching Section 2.6 of reference poster
  renderTimeline(timeline = []) {
    if (!timeline || timeline.length === 0) {
      return `<p class="text-xs text-slate-500 py-3">No activity recorded yet.</p>`;
    }

    return `
      <div class="timeline-track">
        ${timeline.map((step, idx) => {
          const isLast = idx === timeline.length - 1;
          const isRejected = step.status === 'Rejected';
          const isResolved = step.status === 'Resolved';
          const icon = isRejected ? this.icons.xCircle : (isResolved || idx < timeline.length - 1 ? this.icons.checkCircle : this.icons.clock);
          const stateClass = isRejected ? 'rejected' : (isLast ? 'active' : 'completed');

          return `
            <div class="timeline-step ${stateClass}">
              <div class="timeline-marker">
                ${icon}
              </div>
              <div class="bg-white p-3 rounded-lg border border-slate-200 shadow-xs">
                <div class="flex items-center justify-between gap-2">
                  <span class="text-xs font-bold text-slate-900">${step.status}</span>
                  <span class="text-[11px] text-slate-500 font-medium">${CampusFixUI.formatDate(step.timestamp)}</span>
                </div>
                <div class="text-[11px] text-slate-500 font-medium mt-0.5">By: <span class="text-slate-700 font-semibold">${step.actor || 'System'}</span></div>
                <p class="text-xs text-slate-600 mt-1">${step.message || ''}</p>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  },

  // Date Formatter
  formatDate(dateString) {
    if (!dateString) return '—';
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return dateString;
      return date.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (e) {
      return dateString;
    }
  },

  // Confirmation Modal
  confirm({ title, message, confirmText = 'Confirm', cancelText = 'Cancel', isDanger = false, onConfirm }) {
    let modal = document.getElementById('cf-confirm-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'cf-confirm-modal';
      modal.className = 'modal-backdrop';
      document.body.appendChild(modal);
    }

    modal.innerHTML = `
      <div class="modal-window p-6 text-center">
        <div class="w-12 h-12 rounded-full mx-auto mb-4 flex items-center justify-center ${isDanger ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'}">
          ${isDanger ? this.icons.alertCircle : this.icons.shieldCheck}
        </div>
        <h3 class="text-base font-bold text-slate-900">${title}</h3>
        <p class="text-xs text-slate-600 mt-2 mb-6">${message}</p>
        <div class="flex items-center justify-center gap-3">
          <button id="modal-cancel-btn" class="btn-secondary text-xs px-4 py-2">${cancelText}</button>
          <button id="modal-confirm-btn" class="${isDanger ? 'btn-danger' : 'btn-primary'} text-xs px-4 py-2">${confirmText}</button>
        </div>
      </div>
    `;

    modal.classList.add('open');

    document.getElementById('modal-cancel-btn').onclick = () => {
      modal.classList.remove('open');
    };

    document.getElementById('modal-confirm-btn').onclick = () => {
      modal.classList.remove('open');
      if (typeof onConfirm === 'function') onConfirm();
    };
  },

  // Demo Reset Handler
  initResetButton(buttonElementId = 'btn-reset-demo') {
    const btn = document.getElementById(buttonElementId);
    if (!btn) return;

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      this.confirm({
        title: 'Reset Demo Data to Initial State?',
        message: 'This will restore all sample BIET student accounts, complaint records, and timelines to their default reference state.',
        confirmText: 'Reset Demo Data',
        isDanger: true,
        onConfirm: () => {
          window.CampusFixStore.resetToFactoryDefaults();
          CampusFixUI.showToast('Demo Reset Completed', 'All records have been restored to initial prototype defaults.', 'success');
          setTimeout(() => {
            window.location.reload();
          }, 600);
        }
      });
    });
  }
};

window.CampusFixUI = CampusFixUI;
