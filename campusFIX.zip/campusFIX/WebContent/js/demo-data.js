/**
 * CampusFix — Smart Campus Issue Reporting & Resolution System
 * Demo Data & LocalStorage State Management Layer
 * Institution: Bansal Institute of Engineering & Technology (BIET), Lucknow
 * 
 * DISCLAIMER: All student accounts, complaint records, staff names, and timestamps
 * contained in this file are simulated and fictional for frontend prototype evaluation.
 */

const CF_STORAGE_KEYS = {
  STUDENTS: 'campusfix_students_data_v1',
  COMPLAINTS: 'campusfix_complaints_data_v1',
  DEPARTMENTS: 'campusfix_departments_data_v1',
  INITIALIZED: 'campusfix_seed_initialized_v1',
  ACTIVE_SESSION: 'campusfix_active_session_v1'
};

// Initial Seed Data - Fictional illustrative records
const CF_INITIAL_DEPARTMENTS = [
  { id: 'DEPT-IT', name: 'IT Department', contact: 'Er. Sandeep Kumar', email: 'it.support@bansaliet.in', status: 'Active' },
  { id: 'DEPT-MAINT', name: 'Maintenance & Infrastructure', contact: 'Mr. R.K. Mishra', email: 'maintenance@bansaliet.in', status: 'Active' },
  { id: 'DEPT-ELEC', name: 'Electrical Works', contact: 'Er. Alok Verma', email: 'electrical@bansaliet.in', status: 'Active' },
  { id: 'DEPT-SAN', name: 'Cleanliness & Sanitation', contact: 'Mr. Dinesh Pal', email: 'sanitation@bansaliet.in', status: 'Active' },
  { id: 'DEPT-ACAD', name: 'Academic & Lab Support', contact: 'Dr. N.C. Sharma', email: 'academic@bansaliet.in', status: 'Active' }
];

const CF_INITIAL_STUDENTS = [
  {
    student_id: 1,
    college_id: 'BIET23CSE001',
    full_name: 'Aman Verma',
    email: 'aman.verma@bansaliet.in',
    mobile: '9876543210',
    department: 'CSE',
    course: 'B.Tech Computer Science & Engineering',
    year: '3rd Year (Semester 5)',
    password: 'Student@123',
    status: 'Verified', // Verified | Not Verified
    created_at: '2025-08-01T10:00:00.000Z'
  },
  {
    student_id: 2,
    college_id: 'BIET23ECE002',
    full_name: 'Priya Singh',
    email: 'priya.singh@bansaliet.in',
    mobile: '9876543211',
    department: 'ECE',
    course: 'B.Tech Electronics & Communication',
    year: '3rd Year (Semester 5)',
    password: 'Student@123',
    status: 'Verified',
    created_at: '2025-08-02T11:30:00.000Z'
  },
  {
    student_id: 3,
    college_id: 'BIET24ME003',
    full_name: 'Rohan Gupta',
    email: 'rohan.gupta@bansaliet.in',
    mobile: '9876543212',
    department: 'ME',
    course: 'B.Tech Mechanical Engineering',
    year: '2nd Year (Semester 3)',
    password: 'Student@123',
    status: 'Not Verified',
    created_at: '2025-08-06T14:15:00.000Z'
  },
  {
    student_id: 4,
    college_id: 'BIET24CE004',
    full_name: 'Sneha Yadav',
    email: 'sneha.yadav@bansaliet.in',
    mobile: '9876543213',
    department: 'CE',
    course: 'B.Tech Civil Engineering',
    year: '2nd Year (Semester 3)',
    password: 'Student@123',
    status: 'Verified',
    created_at: '2025-08-05T09:40:00.000Z'
  }
];

const CF_INITIAL_COMPLAINTS = [
  {
    complaint_id: 'BIET2025-001',
    student_id: 1,
    student_college_id: 'BIET23CSE001',
    student_name: 'Aman Verma',
    student_dept: 'CSE',
    category: 'Internet / Wi-Fi',
    location: 'Academic Block A (Floor 2, Room 204)',
    description: 'Wi-Fi connectivity has been completely dead in Academic Block A since last 3 days. Students and faculty are unable to access the internal intranet and academic portals.',
    priority: 'High',
    image_url: '',
    status: 'In Progress', // Submitted | Under Verification | Rejected | Forwarded to Management | In Progress | Resolved
    is_genuine: true,
    assigned_dept: 'IT Department',
    expected_resolution_days: '3 Days',
    expected_resolution_date: '2025-08-16',
    remarks: 'Forwarded to IT Department. Cable engineer deployed to replace faulty gateway router in Block A switch room.',
    rejection_reason: '',
    created_at: '2025-08-12T10:30:00.000Z',
    timeline: [
      {
        status: 'Submitted',
        actor: 'Student (Aman Verma)',
        timestamp: '2025-08-12T10:30:00.000Z',
        message: 'Complaint submitted with high priority.'
      },
      {
        status: 'Under Verification',
        actor: 'College Admin',
        timestamp: '2025-08-12T14:15:00.000Z',
        message: 'Student details authenticated. Issue verified as genuine campus network failure.'
      },
      {
        status: 'Forwarded to Management',
        actor: 'College Admin',
        timestamp: '2025-08-13T11:00:00.000Z',
        message: 'Forwarded to IT Department. Assigned resolution timeframe: 3 Days.'
      },
      {
        status: 'In Progress',
        actor: 'IT Department (Er. Sandeep Kumar)',
        timestamp: '2025-08-13T12:00:00.000Z',
        message: 'Issue has been forwarded to IT department and will be resolved within 3 days. Switch diagnostics running.'
      }
    ]
  },
  {
    complaint_id: 'BIET2025-002',
    student_id: 2,
    student_college_id: 'BIET23ECE002',
    student_name: 'Priya Singh',
    student_dept: 'ECE',
    category: 'Infrastructure',
    location: 'Central Computer Center (Lab 3)',
    description: 'Ceiling projector in Lab 3 is not powering on. Presentation display flickers violently and displays lamp overheat error.',
    priority: 'Medium',
    image_url: '',
    status: 'Resolved',
    is_genuine: true,
    assigned_dept: 'IT Department',
    expected_resolution_days: '2 Days',
    expected_resolution_date: '2025-08-12',
    remarks: 'Projector HDMI port tested and optical lamp module replaced. Verified fully operational.',
    rejection_reason: '',
    created_at: '2025-08-10T09:15:00.000Z',
    timeline: [
      {
        status: 'Submitted',
        actor: 'Student (Priya Singh)',
        timestamp: '2025-08-10T09:15:00.000Z',
        message: 'Complaint submitted by Priya Singh.'
      },
      {
        status: 'Under Verification',
        actor: 'College Admin',
        timestamp: '2025-08-10T11:30:00.000Z',
        message: 'Verified with Lab 3 assistant.'
      },
      {
        status: 'Forwarded to Management',
        actor: 'College Admin',
        timestamp: '2025-08-10T14:00:00.000Z',
        message: 'Forwarded to Hardware and Audio-Visual team.'
      },
      {
        status: 'In Progress',
        actor: 'Hardware Maintenance',
        timestamp: '2025-08-11T10:00:00.000Z',
        message: 'New replacement lamp installed. Testing video input sync.'
      },
      {
        status: 'Resolved',
        actor: 'College Admin',
        timestamp: '2025-08-12T16:30:00.000Z',
        message: 'Resolution confirmed. Lab 3 projector is functional.'
      }
    ]
  },
  {
    complaint_id: 'BIET2025-003',
    student_id: 3,
    student_college_id: 'BIET24ME003',
    student_name: 'Rohan Gupta',
    student_dept: 'ME',
    category: 'Cleanliness',
    location: 'Mechanical Block (2nd Floor Restroom)',
    description: 'Water leakage from the main supply tap in 2nd floor restroom causing dampness and slippery floor.',
    priority: 'Low',
    image_url: '',
    status: 'Under Verification',
    is_genuine: null,
    assigned_dept: '',
    expected_resolution_days: '',
    expected_resolution_date: '',
    remarks: '',
    rejection_reason: '',
    created_at: '2025-08-08T11:45:00.000Z',
    timeline: [
      {
        status: 'Submitted',
        actor: 'Student (Rohan Gupta)',
        timestamp: '2025-08-08T11:45:00.000Z',
        message: 'Complaint submitted for sanitation check.'
      },
      {
        status: 'Under Verification',
        actor: 'College Admin',
        timestamp: '2025-08-09T09:30:00.000Z',
        message: 'Pending student enrollment verification and site inspection.'
      }
    ]
  },
  {
    complaint_id: 'BIET2025-004',
    student_id: 3,
    student_college_id: 'BIET24ME003',
    student_name: 'Rohan Gupta',
    student_dept: 'ME',
    category: 'Others',
    location: 'Campus Quadrangle',
    description: 'Music playing too loudly near the lawn area during exam preparatory hours.',
    priority: 'Low',
    image_url: '',
    status: 'Rejected',
    is_genuine: false,
    assigned_dept: '',
    expected_resolution_days: '',
    expected_resolution_date: '',
    remarks: '',
    rejection_reason: 'Non-infrastructure complaint. Noise disturbances must be reported immediately to the Campus Proctorial Board in person.',
    created_at: '2025-08-07T14:00:00.000Z',
    timeline: [
      {
        status: 'Submitted',
        actor: 'Student (Rohan Gupta)',
        timestamp: '2025-08-07T14:00:00.000Z',
        message: 'Complaint submitted.'
      },
      {
        status: 'Rejected',
        actor: 'College Admin',
        timestamp: '2025-08-07T16:30:00.000Z',
        message: 'Rejected by Admin. Reason: Non-infrastructure complaint. Direct to Proctorial Board.'
      }
    ]
  },
  {
    complaint_id: 'BIET2025-005',
    student_id: 4,
    student_college_id: 'BIET24CE004',
    student_name: 'Sneha Yadav',
    student_dept: 'CE',
    category: 'Electrical',
    location: 'Civil Block (Classroom C-102)',
    description: 'Three tube lights are dysfunctional causing inadequate illumination in late evening lecture sessions.',
    priority: 'Medium',
    image_url: '',
    status: 'Forwarded to Management',
    is_genuine: true,
    assigned_dept: 'Electrical Works',
    expected_resolution_days: '2 Days',
    expected_resolution_date: '2025-08-15',
    remarks: 'Forwarded to Electrical Maintenance team for LED tube replacement.',
    rejection_reason: '',
    created_at: '2025-08-11T16:20:00.000Z',
    timeline: [
      {
        status: 'Submitted',
        actor: 'Student (Sneha Yadav)',
        timestamp: '2025-08-11T16:20:00.000Z',
        message: 'Issue reported.'
      },
      {
        status: 'Under Verification',
        actor: 'College Admin',
        timestamp: '2025-08-12T09:10:00.000Z',
        message: 'Verified by department proctor.'
      },
      {
        status: 'Forwarded to Management',
        actor: 'College Admin',
        timestamp: '2025-08-12T11:45:00.000Z',
        message: 'Assigned to Electrical Works. Expected resolution date: 15-08-2025.'
      }
    ]
  }
];

// CampusFix LocalStorage Store Class
class CampusFixDataStore {
  constructor() {
    this.init();
  }

  init() {
    try {
      if (!localStorage.getItem(CF_STORAGE_KEYS.INITIALIZED)) {
        this.resetToFactoryDefaults();
      }
    } catch (e) {
      console.warn('LocalStorage unavailable, running in fallback memory mode:', e);
    }
  }

  resetToFactoryDefaults() {
    localStorage.setItem(CF_STORAGE_KEYS.DEPARTMENTS, JSON.stringify(CF_INITIAL_DEPARTMENTS));
    localStorage.setItem(CF_STORAGE_KEYS.STUDENTS, JSON.stringify(CF_INITIAL_STUDENTS));
    localStorage.setItem(CF_STORAGE_KEYS.COMPLAINTS, JSON.stringify(CF_INITIAL_COMPLAINTS));
    localStorage.setItem(CF_STORAGE_KEYS.INITIALIZED, 'true');
    console.log('CampusFix: LocalStorage data store successfully seeded with BIET institutional demo records.');
  }

  // --- Students API ---
  getStudents() {
    try {
      const data = localStorage.getItem(CF_STORAGE_KEYS.STUDENTS);
      return data ? JSON.parse(data) : [...CF_INITIAL_STUDENTS];
    } catch (e) {
      return [...CF_INITIAL_STUDENTS];
    }
  }

  getStudentById(collegeId) {
    const students = this.getStudents();
    return students.find(s => s.college_id.trim().toUpperCase() === collegeId.trim().toUpperCase()) || null;
  }

  saveStudent(studentObj) {
    const students = this.getStudents();
    const existingIndex = students.findIndex(s => s.college_id.trim().toUpperCase() === studentObj.college_id.trim().toUpperCase());
    
    if (existingIndex >= 0) {
      students[existingIndex] = { ...students[existingIndex], ...studentObj };
    } else {
      const nextId = students.length > 0 ? Math.max(...students.map(s => s.student_id || 0)) + 1 : 1;
      studentObj.student_id = nextId;
      studentObj.created_at = new Date().toISOString();
      students.push(studentObj);
    }
    localStorage.setItem(CF_STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    return studentObj;
  }

  updateStudentVerification(collegeId, isVerified) {
    const students = this.getStudents();
    const target = students.find(s => s.college_id.trim().toUpperCase() === collegeId.trim().toUpperCase());
    if (target) {
      target.status = isVerified ? 'Verified' : 'Not Verified';
      localStorage.setItem(CF_STORAGE_KEYS.STUDENTS, JSON.stringify(students));
      return target;
    }
    return null;
  }

  // --- Complaints API ---
  getComplaints() {
    try {
      const data = localStorage.getItem(CF_STORAGE_KEYS.COMPLAINTS);
      return data ? JSON.parse(data) : [...CF_INITIAL_COMPLAINTS];
    } catch (e) {
      return [...CF_INITIAL_COMPLAINTS];
    }
  }

  getComplaintById(complaintId) {
    const complaints = this.getComplaints();
    return complaints.find(c => c.complaint_id.trim().toUpperCase() === complaintId.trim().toUpperCase()) || null;
  }

  getComplaintsByStudent(collegeId) {
    const complaints = this.getComplaints();
    return complaints.filter(c => c.student_college_id.trim().toUpperCase() === collegeId.trim().toUpperCase());
  }

  generateNextComplaintId() {
    const complaints = this.getComplaints();
    const currentYear = new Date().getFullYear();
    const prefix = `BIET${currentYear}-`;
    const yearComplaints = complaints.filter(c => c.complaint_id.startsWith(prefix));
    
    let maxNum = 0;
    yearComplaints.forEach(c => {
      const part = c.complaint_id.replace(prefix, '');
      const parsed = parseInt(part, 10);
      if (!isNaN(parsed) && parsed > maxNum) {
        maxNum = parsed;
      }
    });

    const nextNum = String(maxNum + 1).padStart(3, '0');
    return `${prefix}${nextNum}`;
  }

  submitComplaint(data, student) {
    const complaints = this.getComplaints();
    const complaintId = this.generateNextComplaintId();
    const now = new Date().toISOString();

    const newComplaint = {
      complaint_id: complaintId,
      student_id: student.student_id,
      student_college_id: student.college_id,
      student_name: student.full_name,
      student_dept: student.department,
      category: data.category,
      location: data.location,
      description: data.description,
      priority: data.priority || 'Medium',
      image_url: data.image_url || '',
      status: 'Submitted',
      is_genuine: null,
      assigned_dept: '',
      expected_resolution_days: '',
      expected_resolution_date: '',
      remarks: '',
      rejection_reason: '',
      created_at: now,
      timeline: [
        {
          status: 'Submitted',
          actor: `Student (${student.full_name})`,
          timestamp: now,
          message: 'Complaint submitted into system and awaiting verification.'
        }
      ]
    };

    complaints.unshift(newComplaint);
    localStorage.setItem(CF_STORAGE_KEYS.COMPLAINTS, JSON.stringify(complaints));
    return newComplaint;
  }

  // Admin verification step
  verifyComplaint(complaintId, isGenuine, rejectionReason = '') {
    const complaints = this.getComplaints();
    const target = complaints.find(c => c.complaint_id === complaintId);
    if (!target) return null;

    const now = new Date().toISOString();
    target.is_genuine = isGenuine;

    if (isGenuine) {
      target.status = 'Under Verification';
      target.timeline.push({
        status: 'Under Verification',
        actor: 'College Admin',
        timestamp: now,
        message: 'Complaint verified as Genuine by administrator.'
      });
    } else {
      target.status = 'Rejected';
      target.rejection_reason = rejectionReason || 'Identified as non-genuine or inappropriate submission.';
      target.timeline.push({
        status: 'Rejected',
        actor: 'College Admin',
        timestamp: now,
        message: `Marked Not Genuine & Rejected: ${target.rejection_reason}`
      });
    }

    localStorage.setItem(CF_STORAGE_KEYS.COMPLAINTS, JSON.stringify(complaints));
    return target;
  }

  // Forward complaint to department
  forwardComplaint(complaintId, departmentName, expectedDays, remarks = '') {
    const complaints = this.getComplaints();
    const target = complaints.find(c => c.complaint_id === complaintId);
    if (!target) return null;

    const now = new Date().toISOString();
    target.status = 'Forwarded to Management';
    target.assigned_dept = departmentName;
    target.expected_resolution_days = expectedDays;
    
    // Calculate expected date
    let daysNum = 3;
    if (expectedDays.includes('1')) daysNum = 1;
    else if (expectedDays.includes('2')) daysNum = 2;
    else if (expectedDays.includes('3')) daysNum = 3;
    else if (expectedDays.includes('5')) daysNum = 5;
    else if (expectedDays.includes('7')) daysNum = 7;
    
    const expDate = new Date();
    expDate.setDate(expDate.getDate() + daysNum);
    target.expected_resolution_date = expDate.toISOString().split('T')[0];
    target.remarks = remarks;

    target.timeline.push({
      status: 'Forwarded to Management',
      actor: 'College Admin',
      timestamp: now,
      message: `Forwarded to ${departmentName} with ${expectedDays} resolution target. Remarks: ${remarks || 'None'}`
    });

    localStorage.setItem(CF_STORAGE_KEYS.COMPLAINTS, JSON.stringify(complaints));
    return target;
  }

  // Update status (In Progress / Resolved)
  updateComplaintStatus(complaintId, newStatus, targetDate, studentMessage) {
    const complaints = this.getComplaints();
    const target = complaints.find(c => c.complaint_id === complaintId);
    if (!target) return null;

    const now = new Date().toISOString();
    target.status = newStatus;
    if (targetDate) {
      target.expected_resolution_date = targetDate;
    }
    if (studentMessage) {
      target.remarks = studentMessage;
    }

    target.timeline.push({
      status: newStatus,
      actor: 'College Admin / Department Lead',
      timestamp: now,
      message: studentMessage || `Status transitioned to ${newStatus}.`
    });

    localStorage.setItem(CF_STORAGE_KEYS.COMPLAINTS, JSON.stringify(complaints));
    return target;
  }

  // Departments
  getDepartments() {
    try {
      const data = localStorage.getItem(CF_STORAGE_KEYS.DEPARTMENTS);
      return data ? JSON.parse(data) : [...CF_INITIAL_DEPARTMENTS];
    } catch (e) {
      return [...CF_INITIAL_DEPARTMENTS];
    }
  }

  // Dashboard Aggregates
  getStats(studentCollegeId = null) {
    const allComplaints = studentCollegeId 
      ? this.getComplaintsByStudent(studentCollegeId)
      : this.getComplaints();

    const stats = {
      total: allComplaints.length,
      submitted: 0,
      under_verification: 0,
      forwarded: 0,
      in_progress: 0,
      resolved: 0,
      rejected: 0,
      pending: 0, // aggregate for simplified card displays: submitted + under_verification + forwarded
      by_category: {
        'Internet / Wi-Fi': 0,
        'Infrastructure': 0,
        'Cleanliness': 0,
        'Electrical': 0,
        'Others': 0
      }
    };

    allComplaints.forEach(c => {
      const s = c.status;
      if (s === 'Submitted') {
        stats.submitted++;
        stats.pending++;
      } else if (s === 'Under Verification') {
        stats.under_verification++;
        stats.pending++;
      } else if (s === 'Forwarded to Management') {
        stats.forwarded++;
        stats.pending++;
      } else if (s === 'In Progress') {
        stats.in_progress++;
      } else if (s === 'Resolved') {
        stats.resolved++;
      } else if (s === 'Rejected') {
        stats.rejected++;
      }

      // Map to poster category buckets
      const cat = c.category;
      if (cat.includes('Wi-Fi') || cat.includes('Internet')) {
        stats.by_category['Internet / Wi-Fi']++;
      } else if (cat.includes('Infrastructure') || cat.includes('Projector')) {
        stats.by_category['Infrastructure']++;
      } else if (cat.includes('Cleanliness') || cat.includes('Sanitation')) {
        stats.by_category['Cleanliness']++;
      } else if (cat.includes('Electrical')) {
        stats.by_category['Electrical']++;
      } else {
        stats.by_category['Others']++;
      }
    });

    return stats;
  }
}

// Global Singleton Instance
window.CampusFixStore = new CampusFixDataStore();
