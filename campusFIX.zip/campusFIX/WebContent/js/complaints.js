/**
 * CampusFix — Smart Campus Issue Reporting & Resolution System
 * Complaints Business Domain Module
 */

const CFComplaints = {
  // Retrieve all complaints
  getAll() {
    return window.CampusFixStore.getComplaints();
  },

  // Retrieve single complaint by ID
  getById(complaintId) {
    if (!complaintId) return null;
    return window.CampusFixStore.getComplaintById(complaintId);
  },

  // Filter complaints by student
  getByStudent(collegeId) {
    if (!collegeId) return [];
    return window.CampusFixStore.getComplaintsByStudent(collegeId);
  },

  // Create and submit complaint
  create(formData, student) {
    if (!student) {
      throw new Error('Student session is required to submit a complaint.');
    }
    return window.CampusFixStore.submitComplaint(formData, student);
  },

  // Admin Verification (Genuine vs Not Genuine)
  verify(complaintId, isGenuine, rejectionReason = '') {
    return window.CampusFixStore.verifyComplaint(complaintId, isGenuine, rejectionReason);
  },

  // Forward to Department
  forward(complaintId, departmentName, expectedDays, remarks = '') {
    return window.CampusFixStore.forwardComplaint(complaintId, departmentName, expectedDays, remarks);
  },

  // Update Status & Remarks
  updateStatus(complaintId, newStatus, expectedDate, studentMessage) {
    return window.CampusFixStore.updateComplaintStatus(complaintId, newStatus, expectedDate, studentMessage);
  },

  // Get Analytics & Stats
  getStats(studentCollegeId = null) {
    return window.CampusFixStore.getStats(studentCollegeId);
  }
};

window.CFComplaints = CFComplaints;
