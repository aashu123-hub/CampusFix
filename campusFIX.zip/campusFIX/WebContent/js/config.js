/**
 * CampusFix — Smart Campus Issue Reporting & Resolution System
 * Configuration & Constant Definitions
 * Institution: Bansal Institute of Engineering & Technology (BIET), Lucknow
 */

const CF_CONFIG = {
  // Institution Meta
  INSTITUTION: {
    NAME: 'Bansal Institute of Engineering & Technology',
    SHORT_NAME: 'BIET',
    LOCATION: 'NH-24, Sitapur Road, behind Sewa Hospital, Lucknow, Uttar Pradesh 226021',
    AFFILIATION: 'Dr. A.P.J. Abdul Kalam Technical University, Lucknow',
    APPROVAL: 'AICTE Approved',
    WEBSITE: 'https://www.bansaliet.in/',
    EMAIL: 'info@bansaliet.in',
    OFFICE: 'Proctorial & Student Grievance Office, Admin Block'
  },

  // Color Tokens for Charts & Inlines
  COLORS: {
    PRIMARY_BLUE: '#2563EB',
    NAVY: '#12366B',
    ADMIN_PURPLE: '#7C3AED',
    SUCCESS: '#16A34A',
    WARNING: '#F59E0B',
    ERROR: '#EF4444',
    BORDER: '#DCE6F5',
    BG_PAGE: '#F5F8FF'
  },

  // Core Complaint Statuses (Exact 6 required statuses)
  STATUSES: {
    SUBMITTED: 'Submitted',
    UNDER_VERIFICATION: 'Under Verification',
    REJECTED: 'Rejected',
    FORWARDED: 'Forwarded to Management',
    IN_PROGRESS: 'In Progress',
    RESOLVED: 'Resolved'
  },

  // Priorities
  PRIORITIES: ['Low', 'Medium', 'High'],

  // Issue Categories matching poster & college requirements
  CATEGORIES: [
    'Internet / Wi-Fi',
    'Infrastructure',
    'Cleanliness',
    'Electrical',
    'Laboratory Equipment',
    'Classroom Projector / AV',
    'Water Supply & Restrooms',
    'Others'
  ],

  // Campus Locations at BIET Lucknow
  LOCATIONS: [
    'Academic Block A',
    'Academic Block B',
    'Central Computer Center (Lab 3)',
    'Mechanical Engineering Block',
    'Electrical & Electronics Block',
    'Civil Engineering Block',
    'Central Library & Reading Hall',
    'Boys Hostel',
    'Girls Hostel',
    'Cafeteria & Student Amenities',
    'Administrative Block'
  ],

  // College Academic Departments
  STUDENT_DEPARTMENTS: [
    { code: 'CSE', name: 'Computer Science & Engineering' },
    { code: 'ECE', name: 'Electronics & Communication' },
    { code: 'ME', name: 'Mechanical Engineering' },
    { code: 'CE', name: 'Civil Engineering' },
    { code: 'IT', name: 'Information Technology' },
    { code: 'AI&ML', name: 'Artificial Intelligence & Machine Learning' }
  ],

  // Resolution Departments
  DEPARTMENTS: [
    { id: 'DEPT-IT', name: 'IT Department', contact: 'Er. Sandeep Kumar', email: 'it.support@bansaliet.in' },
    { id: 'DEPT-MAINT', name: 'Maintenance & Infrastructure', contact: 'Mr. R.K. Mishra', email: 'maintenance@bansaliet.in' },
    { id: 'DEPT-ELEC', name: 'Electrical Works', contact: 'Er. Alok Verma', email: 'electrical@bansaliet.in' },
    { id: 'DEPT-SAN', name: 'Cleanliness & Sanitation', contact: 'Mr. Dinesh Pal', email: 'sanitation@bansaliet.in' },
    { id: 'DEPT-ACAD', name: 'Academic & Lab Support', contact: 'Dr. N.C. Sharma', email: 'academic@bansaliet.in' }
  ],

  // LocalStorage Keys
  STORAGE_KEYS: {
    STUDENTS: 'campusfix_students_data_v1',
    COMPLAINTS: 'campusfix_complaints_data_v1',
    DEPARTMENTS: 'campusfix_departments_data_v1',
    ACTIVE_SESSION: 'campusfix_active_session_v1',
    INITIALIZED: 'campusfix_seed_initialized_v1'
  }
};

window.CF_CONFIG = CF_CONFIG;
