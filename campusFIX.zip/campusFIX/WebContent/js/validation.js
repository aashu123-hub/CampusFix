/**
 * CampusFix — Smart Campus Issue Reporting & Resolution System
 * Form Validation Utilities
 */

const CFValidation = {
  // Validate BIET College Unique ID
  validateCollegeId(id) {
    if (!id || typeof id !== 'string') {
      return { isValid: false, message: 'College Unique ID is required.' };
    }
    const clean = id.trim().toUpperCase();
    if (!clean.startsWith('BIET')) {
      return { isValid: false, message: 'College ID must begin with institutional prefix "BIET" (e.g. BIET23CSE001).' };
    }
    if (clean.length < 8 || clean.length > 15) {
      return { isValid: false, message: 'Invalid College ID length. Expected format e.g. BIET23CSE001.' };
    }
    return { isValid: true, value: clean };
  },

  // Validate Email
  validateEmail(email) {
    if (!email) return { isValid: false, message: 'Email address is required.' };
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      return { isValid: false, message: 'Please enter a valid email address.' };
    }
    return { isValid: true, value: email.trim().toLowerCase() };
  },

  // Validate Mobile
  validateMobile(mobile) {
    if (!mobile) return { isValid: false, message: 'Mobile number is required.' };
    const digitsOnly = mobile.trim().replace(/\D/g, '');
    if (digitsOnly.length !== 10) {
      return { isValid: false, message: 'Mobile number must be exactly 10 digits.' };
    }
    return { isValid: true, value: digitsOnly };
  },

  // Validate Password
  validatePassword(password) {
    if (!password) return { isValid: false, message: 'Password is required.' };
    if (password.length < 6) {
      return { isValid: false, message: 'Password must be at least 6 characters.' };
    }
    return { isValid: true };
  },

  // Required Field Check
  validateRequired(value, fieldLabel = 'Field') {
    if (value === undefined || value === null || String(value).trim() === '') {
      return { isValid: false, message: `${fieldLabel} is required.` };
    }
    return { isValid: true };
  },

  // Display error message under form input
  showError(inputElement, message) {
    if (!inputElement) return;
    inputElement.classList.add('error');
    let errEl = inputElement.parentElement.querySelector('.form-error-msg');
    if (!errEl) {
      errEl = document.createElement('p');
      errEl.className = 'form-error-msg text-xs text-red-600 mt-1 font-medium';
      inputElement.parentElement.appendChild(errEl);
    }
    errEl.textContent = message;
  },

  // Clear error on input
  clearError(inputElement) {
    if (!inputElement) return;
    inputElement.classList.remove('error');
    const errEl = inputElement.parentElement.querySelector('.form-error-msg');
    if (errEl) errEl.remove();
  },

  // Clear all errors in a form
  clearAllErrors(formElement) {
    if (!formElement) return;
    formElement.querySelectorAll('.error').forEach(el => el.classList.remove('error'));
    formElement.querySelectorAll('.form-error-msg').forEach(el => el.remove());
  }
};

window.CFValidation = CFValidation;
