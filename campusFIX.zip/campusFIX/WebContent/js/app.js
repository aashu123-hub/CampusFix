/**
 * CampusFix — Smart Campus Issue Reporting & Resolution System
 * Global Application Bootstrap & Navigation Controller
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Initialize Storage & Seed Data
  if (window.CampusFixStore) {
    window.CampusFixStore.init();
  }

  // 2. Setup Mobile Sidebar Toggle
  const sidebar = document.getElementById('app-sidebar');
  const toggleBtn = document.getElementById('btn-toggle-sidebar');
  const closeBtn = document.getElementById('btn-close-sidebar');

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('open');
    });
  }

  if (closeBtn && sidebar) {
    closeBtn.addEventListener('click', () => {
      sidebar.classList.remove('open');
    });
  }

  // Close sidebar on outer click on mobile
  document.addEventListener('click', (e) => {
    if (sidebar && sidebar.classList.contains('open')) {
      if (!sidebar.contains(e.target) && (!toggleBtn || !toggleBtn.contains(e.target))) {
        sidebar.classList.remove('open');
      }
    }
  });

  // 3. Highlight Active Navigation Item based on current path
  const currentPath = window.location.pathname.toLowerCase();
  document.querySelectorAll('.nav-item').forEach(link => {
    const href = (link.getAttribute('href') || '').toLowerCase();
    if (href && currentPath.endsWith(href.replace('../', ''))) {
      link.classList.add('active');
    }
  });

  // 4. Populate Current User Info in Header if present
  if (window.CampusFixAuth) {
    const session = window.CampusFixAuth.getSession();
    if (session && session.user) {
      const u = session.user;
      const nameEl = document.getElementById('user-display-name');
      const idEl = document.getElementById('user-display-id');
      const badgeEl = document.getElementById('user-display-badge');

      if (nameEl) nameEl.textContent = u.full_name || u.admin_id;
      if (idEl) idEl.textContent = u.college_id || u.admin_id;
      if (badgeEl && u.status) {
        badgeEl.innerHTML = CampusFixUI.renderStudentVerifiedBadge(u.status);
      }
    }
  }

  // 5. Global Logout Handlers
  document.querySelectorAll('.btn-action-logout').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      CampusFixUI.confirm({
        title: 'Sign Out?',
        message: 'Are you sure you want to end your active session?',
        confirmText: 'Sign Out',
        cancelText: 'Stay',
        isDanger: false,
        onConfirm: () => {
          window.CampusFixAuth.logout();
        }
      });
    });
  });

  // 6. Reset Demo Data Trigger
  CampusFixUI.initResetButton('btn-reset-demo');
});
