/**
 * CampusFix — Smart Campus Issue Reporting & Resolution System
 * LocalStorage Service Wrapper
 */

const CFStorage = {
  get(key, defaultValue = null) {
    try {
      const item = localStorage.getItem(key);
      if (item === null || item === undefined) return defaultValue;
      return JSON.parse(item);
    } catch (err) {
      console.warn(`[CFStorage] Error reading key "${key}":`, err);
      return defaultValue;
    }
  },

  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.error(`[CFStorage] Error writing key "${key}":`, err);
      return false;
    }
  },

  remove(key) {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (err) {
      console.warn(`[CFStorage] Error removing key "${key}":`, err);
      return false;
    }
  },

  has(key) {
    return localStorage.getItem(key) !== null;
  },

  clear() {
    try {
      localStorage.clear();
      return true;
    } catch (err) {
      console.error('[CFStorage] Error clearing storage:', err);
      return false;
    }
  }
};

window.CFStorage = CFStorage;
