/**
 * CampusFix — Smart Campus Issue Reporting & Resolution System
 * Authentication & Session Management Module
 * Institution: Bansal Institute of Engineering & Technology (BIET), Lucknow
 */

const CF_AUTH_SESSION_KEY = 'campusfix_active_session_v1';

const CampusFixAuth = {
  // Retrieve currently active session
  getSession() {
    try {
      const data = localStorage.getItem(CF_AUTH_SESSION_KEY);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  },

  // Set active user session
  setSession(role, user) {
    const session = {
      role, // 'student' | 'admin'
      user,
      loginTime: new Date().toISOString()
    };
    localStorage.setItem(CF_AUTH_SESSION_KEY, JSON.stringify(session));
    return session;
  },

  // Student Authentication
  loginStudent(collegeId, password) {
    const cleanId = (collegeId || '').trim().toUpperCase();
    const cleanPass = (password || '').trim();

    if (!cleanId || !cleanPass) {
      return { success: false, error: 'Please enter both College Unique ID and Password.' };
    }

    const student = window.CampusFixStore.getStudentById(cleanId);
    if (!student) {
      return { success: false, error: `Student with College ID "${cleanId}" not found in institutional directory.` };
    }

    if (student.password !== cleanPass) {
      return { success: false, error: 'Incorrect password entered. Please verify your credentials.' };
    }

    this.setSession('student', {
      student_id: student.student_id,
      college_id: student.college_id,
      full_name: student.full_name,
      email: student.email,
      department: student.department,
      course: student.course,
      year: student.year,
      status: student.status
    });

    return { success: true, user: student };
  },

  // Student Registration
  registerStudent(formData) {
    const { college_id, full_name, email, mobile, department, course, year, password, confirm_password } = formData;

    const cleanId = (college_id || '').trim().toUpperCase();
    const cleanName = (full_name || '').trim();
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanMobile = (mobile || '').trim();
    const cleanDept = (department || 'CSE').trim();

    // Validation
    if (!cleanId) return { success: false, error: 'College Unique ID is required (e.g. BIET24CSE015).' };
    if (!cleanId.startsWith('BIET')) {
      return { success: false, error: 'College Unique ID must begin with institutional prefix "BIET" (e.g., BIET24CSE015).' };
    }

    if (!cleanName || cleanName.length < 3) {
      return { success: false, error: 'Please enter your complete official name.' };
    }

    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return { success: false, error: 'Please provide a valid email address.' };
    }

    if (!cleanMobile || !/^\d{10}$/.test(cleanMobile)) {
      return { success: false, error: 'Please enter a valid 10-digit mobile number.' };
    }

    if (!password || password.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters long.' };
    }

    if (password !== confirm_password) {
      return { success: false, error: 'Passwords do not match. Please re-enter.' };
    }

    // Check if ID already exists
    const existing = window.CampusFixStore.getStudentById(cleanId);
    if (existing) {
      return { success: false, error: `Student account with College ID "${cleanId}" is already registered. Please proceed to login.` };
    }

    // Create student record (Status: 'Not Verified' initially until Admin verifies)
    const newStudent = {
      college_id: cleanId,
      full_name: cleanName,
      email: cleanEmail,
      mobile: cleanMobile,
      department: cleanDept,
      course: course || `B.Tech in ${cleanDept}`,
      year: year || '1st Year',
      password: password,
      status: 'Not Verified',
      created_at: new Date().toISOString()
    };

    window.CampusFixStore.saveStudent(newStudent);

    // Auto-login registered student
    this.setSession('student', newStudent);

    return { success: true, user: newStudent };
  },

  // College Admin Authentication
  loginAdmin(adminId, password) {
    const cleanId = (adminId || '').trim();
    const cleanPass = (password || '').trim();

    if (!cleanId || !cleanPass) {
      return { success: false, error: 'Please provide Admin ID and Password.' };
    }

    // Official administrative demo credentials
    if (cleanId === 'admin' && cleanPass === 'admin123') {
      const adminUser = {
        admin_id: 'admin',
        full_name: 'College Admin (Proctorial & Discipline Office)',
        designation: 'Chief Administrative Officer',
        email: 'info@bansaliet.in',
        institution: 'Bansal Institute of Engineering & Technology, Lucknow'
      };
      this.setSession('admin', adminUser);
      return { success: true, user: adminUser };
    }

    return { success: false, error: 'Invalid Administrator credentials. Default demo login is "admin" / "admin123".' };
  },

  // Terminate session
  logout(redirectUrl = null) {
    localStorage.removeItem(CF_AUTH_SESSION_KEY);
    const isSubdir = window.location.pathname.includes('/admin/') || window.location.pathname.includes('/student/');
    const logoutEndpoint = isSubdir ? '../logout' : 'logout';

    try {
      if (typeof fetch === 'function') {
        fetch(logoutEndpoint, { method: 'POST', credentials: 'include' }).catch(() => {});
      }
    } catch (e) {}

    if (redirectUrl) {
      window.location.href = redirectUrl;
    } else {
      window.location.href = isSubdir ? '../index.html' : 'index.html';
    }
  },

  // Guard for protected pages
  requireAuth(requiredRole, redirectPath) {
    const session = this.getSession();
    if (!session || session.role !== requiredRole) {
      const isSubdir = window.location.pathname.includes('/admin/') || window.location.pathname.includes('/student/');
      const target = redirectPath || (isSubdir ? '../index.html' : 'index.html');
      window.location.href = target;
      return false;
    }
    return true;
  },

  // Quick switch demo user for testing convenience
  switchDemoUser(targetKey) {
    if (targetKey === 'admin') {
      this.loginAdmin('admin', 'admin123');
      return true;
    }

    const students = window.CampusFixStore.getStudents();
    const target = students.find(s => s.college_id.toLowerCase() === targetKey.toLowerCase());
    if (target) {
      this.setSession('student', target);
      return true;
    }
    return false;
  }
};

window.CampusFixAuth = CampusFixAuth;
