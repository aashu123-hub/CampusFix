-- =============================================================================
-- CampusFix — Smart Campus Issue Reporting & Resolution System
-- Database Schema for MySQL 8 (Non-Destructive Initialization)
-- Database Name: campusfix_db
-- =============================================================================

CREATE DATABASE IF NOT EXISTS `campusfix_db`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `campusfix_db`;

-- -----------------------------------------------------------------------------
-- 1. Table: departments (Campus Maintenance & Operational Units)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `departments` (
  `dept_id` VARCHAR(50) NOT NULL,
  `dept_name` VARCHAR(100) NOT NULL,
  `contact_person` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 2. Table: students (Enrolled College Students)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `students` (
  `student_id` INT AUTO_INCREMENT NOT NULL,
  `college_id` VARCHAR(50) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `mobile` VARCHAR(20) NOT NULL,
  `department` VARCHAR(50) NOT NULL,
  `course` VARCHAR(50) NOT NULL,
  `year` VARCHAR(20) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `status` ENUM('Verified', 'Not Verified') NOT NULL DEFAULT 'Not Verified',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `uk_students_college_id` (`college_id`),
  UNIQUE KEY `uk_students_email` (`email`),
  KEY `idx_students_department` (`department`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 3. Table: admins (Proctorial Board & Administrative Officers)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admins` (
  `admin_id` VARCHAR(50) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `designation` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `institution` VARCHAR(150) NOT NULL DEFAULT 'Campus Administration',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `uk_admins_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 4. Table: complaints (Campus Grievance Records)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `complaints` (
  `complaint_id` VARCHAR(50) NOT NULL,
  `student_college_id` VARCHAR(50) NOT NULL,
  `student_name` VARCHAR(100) NOT NULL,
  `student_dept` VARCHAR(50) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `location` VARCHAR(150) NOT NULL,
  `description` TEXT NOT NULL,
  `priority` ENUM('Low', 'Medium', 'High') NOT NULL DEFAULT 'Medium',
  `status` ENUM('Submitted', 'Under Verification', 'Rejected', 'Forwarded to Management', 'In Progress', 'Resolved') NOT NULL DEFAULT 'Submitted',
  `assigned_dept` VARCHAR(100) DEFAULT NULL,
  `expected_resolution_days` VARCHAR(50) DEFAULT NULL,
  `expected_resolution_date` DATE DEFAULT NULL,
  `remarks` TEXT DEFAULT NULL,
  `image_url` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`complaint_id`),
  KEY `idx_complaints_student_college_id` (`student_college_id`),
  KEY `idx_complaints_status` (`status`),
  KEY `idx_complaints_category` (`category`),
  KEY `idx_complaints_created_at` (`created_at`),
  CONSTRAINT `fk_complaints_student`
    FOREIGN KEY (`student_college_id`) REFERENCES `students` (`college_id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 5. Table: complaint_history (Chronological Lifecycle Audit Log)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `complaint_history` (
  `history_id` INT AUTO_INCREMENT NOT NULL,
  `complaint_id` VARCHAR(50) NOT NULL,
  `status` VARCHAR(50) NOT NULL,
  `actor` VARCHAR(100) NOT NULL,
  `message` TEXT NOT NULL,
  `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`history_id`),
  KEY `idx_history_complaint_id` (`complaint_id`),
  KEY `idx_history_timestamp` (`timestamp`),
  CONSTRAINT `fk_history_complaints`
    FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`complaint_id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 6. View: complaint_timeline (Backward Compatibility View for Timeline Queries)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW `complaint_timeline` AS
  SELECT
    `history_id` AS `timeline_id`,
    `complaint_id`,
    `status`,
    `actor`,
    `message`,
    `timestamp`
  FROM `complaint_history`;
