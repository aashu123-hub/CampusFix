-- =============================================================================
-- CampusFix — Demonstration & Testing Data (Optional Seed Script)
-- Note: Contains sample demonstration accounts with SHA-256 hashed credentials.
-- These are test records and do NOT represent genuine student records.
-- =============================================================================

USE `campusfix_db`;

-- -----------------------------------------------------------------------------
-- 1. Departments
-- -----------------------------------------------------------------------------
INSERT INTO `departments` (`dept_id`, `dept_name`, `contact_person`, `email`) VALUES
('DEPT-IT', 'IT Infrastructure & Network Support', 'Network Administrator', 'it-support@campusfix.local'),
('DEPT-MAINT', 'Civil & General Maintenance', 'Maintenance Supervisor', 'maintenance@campusfix.local'),
('DEPT-ELEC', 'Electrical Services', 'Chief Electrician', 'electrical@campusfix.local'),
('DEPT-SAN', 'Campus Cleanliness & Sanitation', 'Sanitation Officer', 'sanitation@campusfix.local'),
('DEPT-ACAD', 'Academic Facilities & Labs', 'Lab Coordinator', 'academic-labs@campusfix.local')
ON DUPLICATE KEY UPDATE `dept_name`=VALUES(`dept_name`), `contact_person`=VALUES(`contact_person`), `email`=VALUES(`email`);

-- -----------------------------------------------------------------------------
-- 2. Admin Accounts
-- Credentials: Username = admin / Password = admin123
-- SHA-256: 240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9
-- -----------------------------------------------------------------------------
INSERT INTO `admins` (`admin_id`, `full_name`, `designation`, `email`, `password_hash`, `institution`) VALUES
('admin', 'Campus Proctorial Administrator', 'Chief Proctor', 'proctor@campusfix.local', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'Campus Administration')
ON DUPLICATE KEY UPDATE `full_name`=VALUES(`full_name`), `password_hash`=VALUES(`password_hash`);

-- -----------------------------------------------------------------------------
-- 3. Demo Student Accounts
-- Credentials: Username = DEMO-STD001 / Password = Student@123
-- SHA-256: b2a1f4fd0a460606b34c8913e2981dac8d2e283d778aba586c416ee2629bfa54
-- -----------------------------------------------------------------------------
INSERT INTO `students` (`college_id`, `full_name`, `email`, `mobile`, `department`, `course`, `year`, `password_hash`, `status`) VALUES
('DEMO-STD001', 'Demo Student One', 'demo1@campusfix.local', '9876543210', 'Computer Science', 'B.Tech CSE', '3rd Year', 'b2a1f4fd0a460606b34c8913e2981dac8d2e283d778aba586c416ee2629bfa54', 'Verified'),
('DEMO-STD002', 'Demo Student Two', 'demo2@campusfix.local', '9876543211', 'Electronics', 'B.Tech ECE', '2nd Year', 'b2a1f4fd0a460606b34c8913e2981dac8d2e283d778aba586c416ee2629bfa54', 'Verified')
ON DUPLICATE KEY UPDATE `full_name`=VALUES(`full_name`), `password_hash`=VALUES(`password_hash`);

-- -----------------------------------------------------------------------------
-- 4. Sample Demonstration Complaints
-- -----------------------------------------------------------------------------
INSERT INTO `complaints` (
  `complaint_id`, `student_college_id`, `student_name`, `student_dept`,
  `category`, `location`, `description`, `priority`, `status`,
  `assigned_dept`, `expected_resolution_days`, `expected_resolution_date`, `remarks`
) VALUES
(
  'DEMO2026-001', 'DEMO-STD001', 'Demo Student One', 'Computer Science',
  'Internet / Wi-Fi', 'Academic Block A, 2nd Floor',
  'Wi-Fi signal drops periodically during programming lab practicals.', 'High', 'Forwarded to Management',
  'IT Infrastructure & Network Support', '3 Days', DATE_ADD(CURRENT_DATE(), INTERVAL 3 DAY),
  'Forwarded to network operations desk for access point configuration.'
),
(
  'DEMO2026-002', 'DEMO-STD002', 'Demo Student Two', 'Electronics',
  'Electrical', 'Central Library, Reading Room 2',
  'Ceiling tube light fixture blinking intermittently above study desks.', 'Medium', 'In Progress',
  'Electrical Services', '2 Days', DATE_ADD(CURRENT_DATE(), INTERVAL 2 DAY),
  'Electrician assigned with replacement LED fittings.'
)
ON DUPLICATE KEY UPDATE `status`=VALUES(`status`), `remarks`=VALUES(`remarks`);

-- -----------------------------------------------------------------------------
-- 5. Chronological History for Demo Complaints
-- -----------------------------------------------------------------------------
INSERT INTO `complaint_history` (`complaint_id`, `status`, `actor`, `message`, `timestamp`) VALUES
('DEMO2026-001', 'Submitted', 'Student (DEMO-STD001)', 'Grievance ticket registered via campus web portal.', '2026-10-17 09:30:00'),
('DEMO2026-001', 'Under Verification', 'Proctorial Administrator', 'Signal degradation verified with lab technician.', '2026-10-17 11:00:00'),
('DEMO2026-001', 'Forwarded to Management', 'Proctorial Administrator', 'Assigned to IT Infrastructure team with 3 Days resolution window.', '2026-10-17 11:45:00'),

('DEMO2026-002', 'Submitted', 'Student (DEMO-STD002)', 'Lighting fault reported in reading room.', '2026-10-17 14:00:00'),
('DEMO2026-002', 'Under Verification', 'Proctorial Administrator', 'Verified during evening campus maintenance inspection.', '2026-10-17 15:30:00'),
('DEMO2026-002', 'Forwarded to Management', 'Proctorial Administrator', 'Forwarded to Electrical Services.', '2026-10-17 16:00:00'),
('DEMO2026-002', 'In Progress', 'Electrical Services', 'Maintenance staff on-site replacing ballast.', '2026-10-18 10:00:00');
