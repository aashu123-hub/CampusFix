package com.campusfix.filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Authorization filter protecting admin portal pages and endpoints.
 */
@WebFilter(filterName = "AdminAuthFilter", urlPatterns = {"/admin/*", "/api/admin/*"})
public class AdminAuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        String uri = req.getRequestURI();

        // Allow public admin login page and action
        if (uri.endsWith("/admin/login.html") ||
            uri.endsWith("/admin/login") ||
            uri.contains("/css/") ||
            uri.contains("/js/") ||
            uri.contains("/assets/")) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = req.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        if ("admin".equals(role)) {
            chain.doFilter(request, response);
            return;
        }

        // Role Rejection / Unauthenticated handling
        boolean isJson = (req.getHeader("Accept") != null && req.getHeader("Accept").contains("application/json")) ||
                         "application/json".equalsIgnoreCase(req.getContentType()) ||
                         uri.contains("/api/");

        if ("student".equals(role)) {
            // Student attempting to access admin controls
            if (isJson) {
                resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
                resp.setContentType("application/json;charset=UTF-8");
                resp.getWriter().write("{\"success\":false,\"error\":\"403 Forbidden: Student accounts are not authorized to access administrative controls.\"}");
            } else {
                resp.sendRedirect(req.getContextPath() + "/student/dashboard.html");
            }
            return;
        }

        // Completely unauthenticated
        if (isJson) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            resp.setContentType("application/json;charset=UTF-8");
            resp.getWriter().write("{\"success\":false,\"error\":\"Administrative authentication required. Access denied.\"}");
        } else {
            resp.sendRedirect(req.getContextPath() + "/admin/login.html");
        }
    }

    @Override
    public void destroy() {
    }
}
