package com.campusfix.filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Authorization filter protecting student portal pages and endpoints.
 */
@WebFilter(filterName = "StudentAuthFilter", urlPatterns = {"/student/*", "/api/student/*"})
public class StudentAuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        String uri = req.getRequestURI();

        // Allow public pages and authentication actions
        if (uri.endsWith("/student/login.html") ||
            uri.endsWith("/student/register.html") ||
            uri.endsWith("/student/login") ||
            uri.endsWith("/student/register") ||
            uri.contains("/css/") ||
            uri.contains("/js/") ||
            uri.contains("/assets/")) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = req.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        // Note: complaint-details.html can be audited by either an authenticated Student OR an Admin
        if (uri.endsWith("/student/complaint-details.html") || uri.contains("/complaint/detail")) {
            if ("student".equals(role) || "admin".equals(role)) {
                chain.doFilter(request, response);
                return;
            }
        } else if ("student".equals(role)) {
            // Standard student pages are accessible to students
            chain.doFilter(request, response);
            return;
        }

        // Role Rejection / Unauthenticated handling
        boolean isJson = (req.getHeader("Accept") != null && req.getHeader("Accept").contains("application/json")) ||
                         "application/json".equalsIgnoreCase(req.getContentType()) ||
                         uri.contains("/api/");

        if ("admin".equals(role)) {
            // Admin attempting to access a student-only endpoint
            if (isJson) {
                resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
                resp.setContentType("application/json;charset=UTF-8");
                resp.getWriter().write("{\"success\":false,\"error\":\"403 Forbidden: Admin accounts cannot access student reporting portal.\"}");
            } else {
                resp.sendRedirect(req.getContextPath() + "/admin/dashboard.html");
            }
            return;
        }

        // Completely unauthenticated
        if (isJson) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            resp.setContentType("application/json;charset=UTF-8");
            resp.getWriter().write("{\"success\":false,\"error\":\"Authentication required. Please log in as a student.\"}");
        } else {
            resp.sendRedirect(req.getContextPath() + "/student/login.html");
        }
    }

    @Override
    public void destroy() {
    }
}
