package com.campusfix.dao;

import com.campusfix.model.Student;
import com.campusfix.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Student records using MySQL 8 JDBC.
 */
public class StudentDAO {

    public Student findByCollegeId(String collegeId) {
        if (collegeId == null) return null;
        String sql = "SELECT student_id, college_id, full_name, email, mobile, department, course, year, password_hash, status, created_at " +
                     "FROM students WHERE UPPER(college_id) = UPPER(?)";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, collegeId.trim());
            rs = ps.executeQuery();
            if (rs.next()) {
                return mapRow(rs);
            }
        } catch (SQLException e) {
            System.err.println("[StudentDAO] findByCollegeId error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return null;
    }

    public Student findByEmail(String email) {
        if (email == null) return null;
        String sql = "SELECT student_id, college_id, full_name, email, mobile, department, course, year, password_hash, status, created_at " +
                     "FROM students WHERE LOWER(email) = LOWER(?)";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, email.trim());
            rs = ps.executeQuery();
            if (rs.next()) {
                return mapRow(rs);
            }
        } catch (SQLException e) {
            System.err.println("[StudentDAO] findByEmail error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return null;
    }

    public List<Student> findAll() {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT student_id, college_id, full_name, email, mobile, department, course, year, password_hash, status, created_at " +
                     "FROM students ORDER BY student_id ASC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            System.err.println("[StudentDAO] findAll error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return list;
    }

    public List<Student> search(String query) {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT student_id, college_id, full_name, email, mobile, department, course, year, password_hash, status, created_at " +
                     "FROM students WHERE UPPER(college_id) LIKE UPPER(?) OR UPPER(full_name) LIKE UPPER(?) OR UPPER(department) LIKE UPPER(?) " +
                     "ORDER BY student_id ASC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            String pattern = "%" + (query != null ? query.trim() : "") + "%";
            ps.setString(1, pattern);
            ps.setString(2, pattern);
            ps.setString(3, pattern);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            System.err.println("[StudentDAO] search error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return list;
    }

    public boolean insert(Student s) {
        String sql = "INSERT INTO students (college_id, full_name, email, mobile, department, course, year, password_hash, status) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, s.getCollegeId().trim().toUpperCase());
            ps.setString(2, s.getFullName().trim());
            ps.setString(3, s.getEmail().trim().toLowerCase());
            ps.setString(4, s.getMobile().trim());
            ps.setString(5, s.getDepartment().trim());
            ps.setString(6, s.getCourse() != null ? s.getCourse().trim() : "B.Tech in " + s.getDepartment());
            ps.setString(7, s.getYear() != null ? s.getYear().trim() : "1st Year");
            ps.setString(8, s.getPasswordHash());
            ps.setString(9, s.getStatus() != null ? s.getStatus() : "Not Verified");
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[StudentDAO] insert error: " + e.getMessage());
            return false;
        } finally {
            DBUtil.close(ps, conn);
        }
    }

    public boolean updateVerificationStatus(String collegeId, String status) {
        String sql = "UPDATE students SET status = ? WHERE UPPER(college_id) = UPPER(?)";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, status);
            ps.setString(2, collegeId.trim());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[StudentDAO] updateVerificationStatus error: " + e.getMessage());
            return false;
        } finally {
            DBUtil.close(ps, conn);
        }
    }

    private Student mapRow(ResultSet rs) throws SQLException {
        Student s = new Student();
        s.setStudentId(rs.getInt("student_id"));
        s.setCollegeId(rs.getString("college_id"));
        s.setFullName(rs.getString("full_name"));
        s.setEmail(rs.getString("email"));
        s.setMobile(rs.getString("mobile"));
        s.setDepartment(rs.getString("department"));
        s.setCourse(rs.getString("course"));
        s.setYear(rs.getString("year"));
        s.setPasswordHash(rs.getString("password_hash"));
        s.setStatus(rs.getString("status"));
        s.setCreatedAt(rs.getTimestamp("created_at"));
        return s;
    }
}
