package com.campusfix.dao;

import com.campusfix.model.Department;
import com.campusfix.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for operational departments.
 */
public class DepartmentDAO {

    public List<Department> findAll() {
        List<Department> list = new ArrayList<>();
        String sql = "SELECT dept_id, dept_name, contact_person, email FROM departments ORDER BY dept_name ASC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Department d = new Department();
                d.setDeptId(rs.getString("dept_id"));
                d.setDeptName(rs.getString("dept_name"));
                d.setContactPerson(rs.getString("contact_person"));
                d.setEmail(rs.getString("email"));
                list.add(d);
            }
        } catch (SQLException e) {
            System.err.println("[DepartmentDAO] findAll error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return list;
    }

    public Department findById(String deptId) {
        String sql = "SELECT dept_id, dept_name, contact_person, email FROM departments WHERE dept_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, deptId);
            rs = ps.executeQuery();
            if (rs.next()) {
                Department d = new Department();
                d.setDeptId(rs.getString("dept_id"));
                d.setDeptName(rs.getString("dept_name"));
                d.setContactPerson(rs.getString("contact_person"));
                d.setEmail(rs.getString("email"));
                return d;
            }
        } catch (SQLException e) {
            System.err.println("[DepartmentDAO] findById error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return null;
    }
}
