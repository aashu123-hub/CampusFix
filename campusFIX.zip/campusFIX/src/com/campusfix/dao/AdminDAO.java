package com.campusfix.dao;

import com.campusfix.model.Admin;
import com.campusfix.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Data Access Object for Admin accounts.
 */
public class AdminDAO {

    public Admin findByAdminId(String adminId) {
        if (adminId == null) return null;
        String sql = "SELECT admin_id, full_name, designation, email, password_hash, institution, created_at " +
                     "FROM admins WHERE admin_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, adminId.trim());
            rs = ps.executeQuery();
            if (rs.next()) {
                Admin a = new Admin();
                a.setAdminId(rs.getString("admin_id"));
                a.setFullName(rs.getString("full_name"));
                a.setDesignation(rs.getString("designation"));
                a.setEmail(rs.getString("email"));
                a.setPasswordHash(rs.getString("password_hash"));
                a.setInstitution(rs.getString("institution"));
                a.setCreatedAt(rs.getTimestamp("created_at"));
                return a;
            }
        } catch (SQLException e) {
            System.err.println("[AdminDAO] findByAdminId error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return null;
    }

    public boolean insert(Admin a) {
        String sql = "INSERT INTO admins (admin_id, full_name, designation, email, password_hash, institution) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, a.getAdminId());
            ps.setString(2, a.getFullName());
            ps.setString(3, a.getDesignation());
            ps.setString(4, a.getEmail());
            ps.setString(5, a.getPasswordHash());
            ps.setString(6, a.getInstitution());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[AdminDAO] insert error: " + e.getMessage());
            return false;
        } finally {
            DBUtil.close(ps, conn);
        }
    }
}
