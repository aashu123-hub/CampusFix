package com.campusfix.dao;

import com.campusfix.model.Complaint;
import com.campusfix.model.TimelineEvent;
import com.campusfix.util.DBUtil;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Year;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Data Access Object for complaints and their resolution timelines using MySQL 8.
 */
public class ComplaintDAO {

    public Complaint findById(String complaintId) {
        if (complaintId == null) return null;
        String sql = "SELECT complaint_id, student_college_id, student_name, student_dept, category, " +
                     "location, description, priority, status, assigned_dept, expected_resolution_days, " +
                     "expected_resolution_date, remarks, image_url, created_at, updated_at " +
                     "FROM complaints WHERE complaint_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, complaintId.trim());
            rs = ps.executeQuery();
            if (rs.next()) {
                Complaint c = mapRow(rs);
                c.setTimeline(getTimelineForComplaint(complaintId, conn));
                return c;
            }
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] findById error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return null;
    }

    public List<Complaint> findAll() {
        List<Complaint> list = new ArrayList<>();
        String sql = "SELECT complaint_id, student_college_id, student_name, student_dept, category, " +
                     "location, description, priority, status, assigned_dept, expected_resolution_days, " +
                     "expected_resolution_date, remarks, image_url, created_at, updated_at " +
                     "FROM complaints ORDER BY created_at DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Complaint c = mapRow(rs);
                list.add(c);
            }
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] findAll error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return list;
    }

    public List<Complaint> findByStudent(String collegeId) {
        List<Complaint> list = new ArrayList<>();
        if (collegeId == null) return list;
        String sql = "SELECT complaint_id, student_college_id, student_name, student_dept, category, " +
                     "location, description, priority, status, assigned_dept, expected_resolution_days, " +
                     "expected_resolution_date, remarks, image_url, created_at, updated_at " +
                     "FROM complaints WHERE UPPER(student_college_id) = UPPER(?) ORDER BY created_at DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, collegeId.trim());
            rs = ps.executeQuery();
            while (rs.next()) {
                Complaint c = mapRow(rs);
                list.add(c);
            }
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] findByStudent error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return list;
    }

    public synchronized String generateNextComplaintId() {
        int currentYear = Year.now().getValue();
        String prefix = "BIET" + currentYear + "-";
        String sql = "SELECT complaint_id FROM complaints WHERE complaint_id LIKE ? ORDER BY complaint_id DESC LIMIT 1";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int nextNum = 1;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, prefix + "%");
            rs = ps.executeQuery();
            if (rs.next()) {
                String latestId = rs.getString("complaint_id");
                String[] parts = latestId.split("-");
                if (parts.length > 1) {
                    try {
                        nextNum = Integer.parseInt(parts[1]) + 1;
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] generateNextComplaintId error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return String.format("%s%03d", prefix, nextNum);
    }

    public boolean insert(Complaint c) {
        String sql = "INSERT INTO complaints (complaint_id, student_college_id, student_name, student_dept, " +
                     "category, location, description, priority, status, image_url) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false);

            ps = conn.prepareStatement(sql);
            ps.setString(1, c.getComplaintId());
            ps.setString(2, c.getStudentCollegeId().toUpperCase());
            ps.setString(3, c.getStudentName());
            ps.setString(4, c.getStudentDept());
            ps.setString(5, c.getCategory());
            ps.setString(6, c.getLocation());
            ps.setString(7, c.getDescription());
            ps.setString(8, c.getPriority() != null ? c.getPriority() : "Medium");
            ps.setString(9, "Submitted");
            ps.setString(10, c.getImageUrl());
            ps.executeUpdate();

            // Insert initial complaint history event
            String timelineSql = "INSERT INTO complaint_history (complaint_id, status, actor, message) VALUES (?, ?, ?, ?)";
            try (PreparedStatement tps = conn.prepareStatement(timelineSql)) {
                tps.setString(1, c.getComplaintId());
                tps.setString(2, "Submitted");
                tps.setString(3, "Student (" + c.getStudentCollegeId() + ")");
                tps.setString(4, "Complaint submitted online via student grievance portal.");
                tps.executeUpdate();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] insert error: " + e.getMessage());
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
            }
            DBUtil.close(ps, conn);
        }
    }

    public boolean updateVerification(String complaintId, boolean isGenuine, String rejectionReason) {
        String newStatus = isGenuine ? "Under Verification" : "Rejected";
        String message = isGenuine
                ? "Complaint marked as Genuine after physical verification of AP/facility signal."
                : "Complaint Rejected: " + (rejectionReason != null ? rejectionReason : "Issue could not be substantiated.");

        String sql = "UPDATE complaints SET status = ?, remarks = ? WHERE complaint_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false);

            ps = conn.prepareStatement(sql);
            ps.setString(1, newStatus);
            ps.setString(2, isGenuine ? "Verified Genuine" : rejectionReason);
            ps.setString(3, complaintId);
            ps.executeUpdate();

            addTimelineEventInternal(conn, complaintId, newStatus, "College Admin (Proctorial Board)", message);

            conn.commit();
            return true;
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] updateVerification error: " + e.getMessage());
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
            }
            DBUtil.close(ps, conn);
        }
    }

    public boolean forwardToDepartment(String complaintId, String deptName, String tenure, String remarks) {
        int days = 3;
        if (tenure != null) {
            if (tenure.contains("1")) days = 1;
            else if (tenure.contains("2")) days = 2;
            else if (tenure.contains("3")) days = 3;
            else if (tenure.contains("5")) days = 5;
            else if (tenure.contains("7")) days = 7;
        }
        long targetMillis = System.currentTimeMillis() + ((long) days * 24 * 60 * 60 * 1000);
        Date targetDate = new Date(targetMillis);

        String sql = "UPDATE complaints SET status = 'Forwarded to Management', assigned_dept = ?, " +
                     "expected_resolution_days = ?, expected_resolution_date = ?, remarks = ? " +
                     "WHERE complaint_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false);

            ps = conn.prepareStatement(sql);
            ps.setString(1, deptName);
            ps.setString(2, tenure);
            ps.setDate(3, targetDate);
            ps.setString(4, remarks);
            ps.setString(5, complaintId);
            ps.executeUpdate();

            String message = "Forwarded to " + deptName + " with " + tenure + " resolution target. Remarks: " + (remarks != null && !remarks.isEmpty() ? remarks : "None");
            addTimelineEventInternal(conn, complaintId, "Forwarded to Management", "College Admin (Proctorial Board)", message);

            conn.commit();
            return true;
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] forwardToDepartment error: " + e.getMessage());
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
            }
            DBUtil.close(ps, conn);
        }
    }

    public boolean updateStatus(String complaintId, String status, Date expectedDate, String remarks) {
        String sql = "UPDATE complaints SET status = ?, remarks = ?" + (expectedDate != null ? ", expected_resolution_date = ?" : "") + " WHERE complaint_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false);

            ps = conn.prepareStatement(sql);
            ps.setString(1, status);
            ps.setString(2, remarks);
            if (expectedDate != null) {
                ps.setDate(3, expectedDate);
                ps.setString(4, complaintId);
            } else {
                ps.setString(3, complaintId);
            }
            ps.executeUpdate();

            String message = (remarks != null && !remarks.isEmpty()) ? remarks : "Complaint status updated to " + status;
            addTimelineEventInternal(conn, complaintId, status, "College Admin", message);

            conn.commit();
            return true;
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] updateStatus error: " + e.getMessage());
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
            }
            DBUtil.close(ps, conn);
        }
    }

    public List<TimelineEvent> getTimelineForComplaint(String complaintId) {
        Connection conn = null;
        try {
            conn = DBUtil.getConnection();
            return getTimelineForComplaint(complaintId, conn);
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] getTimelineForComplaint error: " + e.getMessage());
            return new ArrayList<>();
        } finally {
            DBUtil.close(conn);
        }
    }

    private List<TimelineEvent> getTimelineForComplaint(String complaintId, Connection conn) {
        List<TimelineEvent> list = new ArrayList<>();
        String sql = "SELECT history_id AS timeline_id, complaint_id, status, actor, message, timestamp " +
                     "FROM complaint_history WHERE complaint_id = ? ORDER BY timestamp ASC, history_id ASC";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, complaintId);
            rs = ps.executeQuery();
            while (rs.next()) {
                TimelineEvent t = new TimelineEvent();
                t.setTimelineId(rs.getInt("timeline_id"));
                t.setComplaintId(rs.getString("complaint_id"));
                t.setStatus(rs.getString("status"));
                t.setActor(rs.getString("actor"));
                t.setMessage(rs.getString("message"));
                t.setTimestamp(rs.getTimestamp("timestamp"));
                list.add(t);
            }
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] getTimelineForComplaint internal error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps);
        }
        return list;
    }

    public boolean addTimelineEvent(TimelineEvent t) {
        Connection conn = null;
        try {
            conn = DBUtil.getConnection();
            addTimelineEventInternal(conn, t.getComplaintId(), t.getStatus(), t.getActor(), t.getMessage());
            return true;
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] addTimelineEvent error: " + e.getMessage());
            return false;
        } finally {
            DBUtil.close(conn);
        }
    }

    private void addTimelineEventInternal(Connection conn, String complaintId, String status, String actor, String message) throws SQLException {
        String sql = "INSERT INTO complaint_history (complaint_id, status, actor, message) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, complaintId);
            ps.setString(2, status);
            ps.setString(3, actor);
            ps.setString(4, message);
            ps.executeUpdate();
        }
    }

    public Map<String, Integer> getStats(String studentCollegeId) {
        Map<String, Integer> stats = new HashMap<>();
        stats.put("total", 0);
        stats.put("pending", 0);
        stats.put("in_progress", 0);
        stats.put("resolved", 0);

        String sql = "SELECT status, COUNT(*) AS cnt FROM complaints " +
                     (studentCollegeId != null ? "WHERE UPPER(student_college_id) = UPPER(?) " : "") +
                     "GROUP BY status";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            if (studentCollegeId != null) {
                ps.setString(1, studentCollegeId.trim());
            }
            rs = ps.executeQuery();
            int total = 0;
            while (rs.next()) {
                String status = rs.getString("status");
                int count = rs.getInt("cnt");
                total += count;
                if ("In Progress".equalsIgnoreCase(status)) {
                    stats.put("in_progress", count);
                } else if ("Resolved".equalsIgnoreCase(status)) {
                    stats.put("resolved", count);
                } else if ("Submitted".equalsIgnoreCase(status) || "Under Verification".equalsIgnoreCase(status) || "Forwarded to Management".equalsIgnoreCase(status)) {
                    stats.put("pending", stats.get("pending") + count);
                }
            }
            stats.put("total", total);
        } catch (SQLException e) {
            System.err.println("[ComplaintDAO] getStats error: " + e.getMessage());
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return stats;
    }

    private Complaint mapRow(ResultSet rs) throws SQLException {
        Complaint c = new Complaint();
        c.setComplaintId(rs.getString("complaint_id"));
        c.setStudentCollegeId(rs.getString("student_college_id"));
        c.setStudentName(rs.getString("student_name"));
        c.setStudentDept(rs.getString("student_dept"));
        c.setCategory(rs.getString("category"));
        c.setLocation(rs.getString("location"));
        c.setDescription(rs.getString("description"));
        c.setPriority(rs.getString("priority"));
        c.setStatus(rs.getString("status"));
        c.setAssignedDept(rs.getString("assigned_dept"));
        c.setExpectedResolutionDays(rs.getString("expected_resolution_days"));
        c.setExpectedResolutionDate(rs.getDate("expected_resolution_date"));
        c.setRemarks(rs.getString("remarks"));
        c.setImageUrl(rs.getString("image_url"));
        c.setCreatedAt(rs.getTimestamp("created_at"));
        c.setUpdatedAt(rs.getTimestamp("updated_at"));
        return c;
    }
}
