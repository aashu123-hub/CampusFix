package com.campusfix.util;

import com.campusfix.model.Admin;
import com.campusfix.model.Complaint;
import com.campusfix.model.Student;
import com.campusfix.model.TimelineEvent;

import java.util.List;

/**
 * Lightweight JSON utility for formatting Servlet API responses.
 */
public class JsonUtil {

    public static String escape(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < ' ') {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }

    public static String successResponse(String message, String dataJson) {
        return "{\"success\":true,\"message\":\"" + escape(message) + "\"" + (dataJson != null ? ",\"data\":" + dataJson : "") + "}";
    }

    public static String errorResponse(String error) {
        return "{\"success\":false,\"error\":\"" + escape(error) + "\"}";
    }

    public static String studentToJson(Student s) {
        if (s == null) return "null";
        return "{" +
                "\"student_id\":" + s.getStudentId() + "," +
                "\"college_id\":\"" + escape(s.getCollegeId()) + "\"," +
                "\"full_name\":\"" + escape(s.getFullName()) + "\"," +
                "\"email\":\"" + escape(s.getEmail()) + "\"," +
                "\"mobile\":\"" + escape(s.getMobile()) + "\"," +
                "\"department\":\"" + escape(s.getDepartment()) + "\"," +
                "\"course\":\"" + escape(s.getCourse()) + "\"," +
                "\"year\":\"" + escape(s.getYear()) + "\"," +
                "\"status\":\"" + escape(s.getStatus()) + "\"" +
                "}";
    }

    public static String adminToJson(Admin a) {
        if (a == null) return "null";
        return "{" +
                "\"admin_id\":\"" + escape(a.getAdminId()) + "\"," +
                "\"full_name\":\"" + escape(a.getFullName()) + "\"," +
                "\"designation\":\"" + escape(a.getDesignation()) + "\"," +
                "\"email\":\"" + escape(a.getEmail()) + "\"," +
                "\"institution\":\"" + escape(a.getInstitution()) + "\"" +
                "}";
    }

    public static String timelineEventToJson(TimelineEvent t) {
        if (t == null) return "null";
        return "{" +
                "\"timeline_id\":" + t.getTimelineId() + "," +
                "\"complaint_id\":\"" + escape(t.getComplaintId()) + "\"," +
                "\"status\":\"" + escape(t.getStatus()) + "\"," +
                "\"actor\":\"" + escape(t.getActor()) + "\"," +
                "\"message\":\"" + escape(t.getMessage()) + "\"," +
                "\"timestamp\":\"" + (t.getTimestamp() != null ? t.getTimestamp().toString() : "") + "\"" +
                "}";
    }

    public static String complaintToJson(Complaint c) {
        if (c == null) return "null";
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"complaint_id\":\"").append(escape(c.getComplaintId())).append("\",");
        sb.append("\"student_college_id\":\"").append(escape(c.getStudentCollegeId())).append("\",");
        sb.append("\"student_name\":\"").append(escape(c.getStudentName())).append("\",");
        sb.append("\"student_dept\":\"").append(escape(c.getStudentDept())).append("\",");
        sb.append("\"category\":\"").append(escape(c.getCategory())).append("\",");
        sb.append("\"location\":\"").append(escape(c.getLocation())).append("\",");
        sb.append("\"description\":\"").append(escape(c.getDescription())).append("\",");
        sb.append("\"priority\":\"").append(escape(c.getPriority())).append("\",");
        sb.append("\"status\":\"").append(escape(c.getStatus())).append("\",");
        sb.append("\"assigned_dept\":\"").append(escape(c.getAssignedDept())).append("\",");
        sb.append("\"expected_resolution_days\":\"").append(escape(c.getExpectedResolutionDays())).append("\",");
        sb.append("\"expected_resolution_date\":\"").append(c.getExpectedResolutionDate() != null ? c.getExpectedResolutionDate().toString() : "").append("\",");
        sb.append("\"remarks\":\"").append(escape(c.getRemarks())).append("\",");
        sb.append("\"image_url\":\"").append(escape(c.getImageUrl())).append("\",");
        sb.append("\"created_at\":\"").append(c.getCreatedAt() != null ? c.getCreatedAt().toString() : "").append("\",");

        sb.append("\"timeline\":[");
        List<TimelineEvent> list = c.getTimeline();
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) sb.append(",");
                sb.append(timelineEventToJson(list.get(i)));
            }
        }
        sb.append("]");
        sb.append("}");
        return sb.toString();
    }

    public static String complaintsListToJson(List<Complaint> list) {
        if (list == null) return "[]";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(complaintToJson(list.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }

    public static String studentsListToJson(List<Student> list) {
        if (list == null) return "[]";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(studentToJson(list.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }
}
