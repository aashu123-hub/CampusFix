package com.campusfix.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Database utility for managing MySQL 8 JDBC connections in Tomcat 10.1.
 */
public class DBUtil {

    private static String dbUrl = "jdbc:mysql://localhost:3306/campusfix_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";
    private static String dbUser = "root";
    private static String dbPassword = "root";
    private static String dbDriver = "com.mysql.cj.jdbc.Driver";

    static {
        try {
            // 1. Load custom db.properties from classpath if available
            InputStream in = DBUtil.class.getClassLoader().getResourceAsStream("db.properties");
            if (in != null) {
                Properties props = new Properties();
                props.load(in);
                if (props.getProperty("db.url") != null) dbUrl = props.getProperty("db.url").trim();
                if (props.getProperty("db.user") != null) dbUser = props.getProperty("db.user").trim();
                if (props.getProperty("db.password") != null) dbPassword = props.getProperty("db.password").trim();
                if (props.getProperty("db.driver") != null) dbDriver = props.getProperty("db.driver").trim();
                in.close();
            }
        } catch (Exception e) {
            System.err.println("[DBUtil] Warning: Could not load db.properties, using defaults: " + e.getMessage());
        }

        // 2. Allow environment variables to override for local deployment flexibility
        String envUrl = System.getenv("CAMPUSFIX_DB_URL") != null ? System.getenv("CAMPUSFIX_DB_URL") : System.getenv("MYSQL_URL");
        String envUser = System.getenv("CAMPUSFIX_DB_USER") != null ? System.getenv("CAMPUSFIX_DB_USER") : System.getenv("MYSQL_USER");
        String envPass = System.getenv("CAMPUSFIX_DB_PASSWORD") != null ? System.getenv("CAMPUSFIX_DB_PASSWORD") : System.getenv("MYSQL_PASSWORD");
        if (envUrl != null && !envUrl.trim().isEmpty()) dbUrl = envUrl.trim();
        if (envUser != null && !envUser.trim().isEmpty()) dbUser = envUser.trim();
        if (envPass != null) dbPassword = envPass.trim();

        try {
            Class.forName(dbDriver);
            System.out.println("[DBUtil] MySQL JDBC Driver loaded: " + dbDriver);
        } catch (ClassNotFoundException e) {
            System.err.println("[DBUtil] Error: MySQL JDBC Driver class not found: " + e.getMessage());
        }
    }

    /**
     * Obtains a new JDBC Connection to MySQL.
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dbUrl, dbUser, dbPassword);
    }

    /**
     * Safely closes one or more AutoCloseable resources (Connection, Statement, ResultSet).
     */
    public static void close(AutoCloseable... resources) {
        if (resources == null) return;
        for (AutoCloseable r : resources) {
            if (r != null) {
                try {
                    r.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    /**
     * Checks if the MySQL database is reachable.
     */
    public static boolean isConnectionAvailable() {
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (Exception e) {
            return false;
        }
    }

    public static String getDbUrl() {
        return dbUrl;
    }

    public static void configure(String url, String user, String password) {
        dbUrl = url;
        dbUser = user;
        dbPassword = password;
    }
}
