package com.campusfix.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model representing an audit event in the lifecycle of a complaint.
 */
public class TimelineEvent implements Serializable {
    private static final long serialVersionUID = 1L;

    private int timelineId;
    private String complaintId;
    private String status;
    private String actor;
    private String message;
    private Timestamp timestamp;

    public TimelineEvent() {}

    public TimelineEvent(String complaintId, String status, String actor, String message, Timestamp timestamp) {
        this.complaintId = complaintId;
        this.status = status;
        this.actor = actor;
        this.message = message;
        this.timestamp = timestamp;
    }

    public int getTimelineId() {
        return timelineId;
    }

    public void setTimelineId(int timelineId) {
        this.timelineId = timelineId;
    }

    public int getHistoryId() {
        return timelineId;
    }

    public void setHistoryId(int historyId) {
        this.timelineId = historyId;
    }

    public String getComplaintId() {
        return complaintId;
    }

    public void setComplaintId(String complaintId) {
        this.complaintId = complaintId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "TimelineEvent{" +
                "complaintId='" + complaintId + '\'' +
                ", status='" + status + '\'' +
                ", actor='" + actor + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}
