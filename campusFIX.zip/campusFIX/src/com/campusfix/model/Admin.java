package com.campusfix.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model representing a BIET Proctorial or Administrative officer.
 */
public class Admin implements Serializable {
    private static final long serialVersionUID = 1L;

    private String adminId;
    private String fullName;
    private String designation;
    private String email;
    private String passwordHash;
    private String institution;
    private Timestamp createdAt;

    public Admin() {}

    public Admin(String adminId, String fullName, String designation, String email, String passwordHash, String institution) {
        this.adminId = adminId;
        this.fullName = fullName;
        this.designation = designation;
        this.email = email;
        this.passwordHash = passwordHash;
        this.institution = institution;
    }

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "Admin{" +
                "adminId='" + adminId + '\'' +
                ", fullName='" + fullName + '\'' +
                ", designation='" + designation + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
