package com.campusfix.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Model representing a campus grievance ticket.
 */
public class Complaint implements Serializable {
    private static final long serialVersionUID = 1L;

    private String complaintId;
    private String studentCollegeId;
    private String studentName;
    private String studentDept;
    private String category;
    private String location;
    private String description;
    private String priority; // 'Low', 'Medium', 'High'
    private String status;   // 'Submitted', 'Under Verification', 'Rejected', 'Forwarded to Management', 'In Progress', 'Resolved'
    private String assignedDept;
    private String expectedResolutionDays;
    private Date expectedResolutionDate;
    private String remarks;
    private String imageUrl;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    private List<TimelineEvent> timeline = new ArrayList<>();

    public Complaint() {}

    public Complaint(String complaintId, String studentCollegeId, String studentName, String studentDept,
                     String category, String location, String description, String priority, String status) {
        this.complaintId = complaintId;
        this.studentCollegeId = studentCollegeId;
        this.studentName = studentName;
        this.studentDept = studentDept;
        this.category = category;
        this.location = location;
        this.description = description;
        this.priority = priority;
        this.status = status;
    }

    public String getComplaintId() {
        return complaintId;
    }

    public void setComplaintId(String complaintId) {
        this.complaintId = complaintId;
    }

    public String getStudentCollegeId() {
        return studentCollegeId;
    }

    public void setStudentCollegeId(String studentCollegeId) {
        this.studentCollegeId = studentCollegeId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentDept() {
        return studentDept;
    }

    public void setStudentDept(String studentDept) {
        this.studentDept = studentDept;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAssignedDept() {
        return assignedDept;
    }

    public void setAssignedDept(String assignedDept) {
        this.assignedDept = assignedDept;
    }

    public String getExpectedResolutionDays() {
        return expectedResolutionDays;
    }

    public void setExpectedResolutionDays(String expectedResolutionDays) {
        this.expectedResolutionDays = expectedResolutionDays;
    }

    public Date getExpectedResolutionDate() {
        return expectedResolutionDate;
    }

    public void setExpectedResolutionDate(Date expectedResolutionDate) {
        this.expectedResolutionDate = expectedResolutionDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<TimelineEvent> getTimeline() {
        return timeline;
    }

    public void setTimeline(List<TimelineEvent> timeline) {
        this.timeline = timeline != null ? timeline : new ArrayList<>();
    }

    public void addTimelineEvent(TimelineEvent event) {
        if (this.timeline == null) {
            this.timeline = new ArrayList<>();
        }
        this.timeline.add(event);
    }

    @Override
    public String toString() {
        return "Complaint{" +
                "complaintId='" + complaintId + '\'' +
                ", studentCollegeId='" + studentCollegeId + '\'' +
                ", category='" + category + '\'' +
                ", status='" + status + '\'' +
                ", priority='" + priority + '\'' +
                '}';
    }
}
