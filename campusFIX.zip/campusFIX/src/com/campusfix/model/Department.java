package com.campusfix.model;

import java.io.Serializable;

/**
 * Model representing a campus operational or maintenance department.
 */
public class Department implements Serializable {
    private static final long serialVersionUID = 1L;

    private String deptId;
    private String deptName;
    private String contactPerson;
    private String email;

    public Department() {}

    public Department(String deptId, String deptName, String contactPerson, String email) {
        this.deptId = deptId;
        this.deptName = deptName;
        this.contactPerson = contactPerson;
        this.email = email;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Department{" +
                "deptId='" + deptId + '\'' +
                ", deptName='" + deptName + '\'' +
                ", contactPerson='" + contactPerson + '\'' +
                '}';
    }
}
