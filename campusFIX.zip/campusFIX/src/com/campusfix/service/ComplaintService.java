package com.campusfix.service;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.model.Complaint;

import java.sql.Date;
import java.util.List;
import java.util.Map;

/**
 * Service managing grievance submission, verification, routing, and lifecycle states.
 */
public class ComplaintService {

    private final ComplaintDAO complaintDAO = new ComplaintDAO();

    public Complaint submitComplaint(Complaint complaint) {
        if (complaint == null) return null;
        if (complaint.getComplaintId() == null || complaint.getComplaintId().trim().isEmpty()) {
            complaint.setComplaintId(complaintDAO.generateNextComplaintId());
        }
        boolean success = complaintDAO.insert(complaint);
        return success ? complaint : null;
    }

    public Complaint getComplaintWithTimeline(String complaintId) {
        return complaintDAO.findById(complaintId);
    }

    public List<Complaint> getComplaintsForStudent(String collegeId) {
        return complaintDAO.findByStudent(collegeId);
    }

    public List<Complaint> getAllComplaints() {
        return complaintDAO.findAll();
    }

    public boolean verifyComplaint(String complaintId, boolean isGenuine, String rejectionReason) {
        return complaintDAO.updateVerification(complaintId, isGenuine, rejectionReason);
    }

    public boolean forwardComplaint(String complaintId, String deptName, String tenure, String remarks) {
        return complaintDAO.forwardToDepartment(complaintId, deptName, tenure, remarks);
    }

    public boolean updateComplaintStatus(String complaintId, String status, Date expectedDate, String remarks) {
        return complaintDAO.updateStatus(complaintId, status, expectedDate, remarks);
    }

    public Map<String, Integer> getStats(String studentCollegeId) {
        return complaintDAO.getStats(studentCollegeId);
    }

    public String generateNextComplaintId() {
        return complaintDAO.generateNextComplaintId();
    }
}
