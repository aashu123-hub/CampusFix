package com.campusfix.service;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.dao.DepartmentDAO;
import com.campusfix.dao.StudentDAO;
import com.campusfix.model.Complaint;
import com.campusfix.model.Department;
import com.campusfix.model.Student;

import java.util.List;
import java.util.Map;

/**
 * Service managing college administration workflows.
 */
public class AdminService {

    private final StudentDAO studentDAO = new StudentDAO();
    private final ComplaintDAO complaintDAO = new ComplaintDAO();
    private final DepartmentDAO departmentDAO = new DepartmentDAO();

    public List<Student> getAllStudents() {
        return studentDAO.findAll();
    }

    public List<Student> searchStudents(String query) {
        return studentDAO.search(query);
    }

    public boolean updateStudentVerification(String collegeId, String status) {
        return studentDAO.updateVerificationStatus(collegeId, status);
    }

    public List<Department> getAllDepartments() {
        return departmentDAO.findAll();
    }

    public List<Complaint> getAllComplaints() {
        return complaintDAO.findAll();
    }

    public Map<String, Integer> getSystemStats() {
        return complaintDAO.getStats(null);
    }
}
