package com.campusfix.service;

import com.campusfix.dao.AdminDAO;
import com.campusfix.dao.StudentDAO;
import com.campusfix.model.Admin;
import com.campusfix.model.Student;
import com.campusfix.util.PasswordUtil;

/**
 * Service orchestrating authentication and registration for students and admins.
 */
public class AuthService {

    private final StudentDAO studentDAO = new StudentDAO();
    private final AdminDAO adminDAO = new AdminDAO();

    public Student authenticateStudent(String collegeId, String password) {
        if (collegeId == null || password == null) return null;
        Student student = studentDAO.findByCollegeId(collegeId.trim());
        if (student == null) {
            return null;
        }
        if (PasswordUtil.verify(password.trim(), student.getPasswordHash())) {
            return student;
        }
        return null;
    }

    public Admin authenticateAdmin(String adminId, String password) {
        if (adminId == null || password == null) return null;
        Admin admin = adminDAO.findByAdminId(adminId.trim());
        if (admin == null) {
            return null;
        }
        if (PasswordUtil.verify(password.trim(), admin.getPasswordHash())) {
            return admin;
        }
        return null;
    }

    public boolean registerStudent(Student student) {
        if (student == null || student.getCollegeId() == null) return false;
        String cleanId = student.getCollegeId().trim().toUpperCase();

        // Enforce institutional prefix
        if (!cleanId.startsWith("BIET")) {
            return false;
        }

        // Prevent duplicate IDs
        if (studentDAO.findByCollegeId(cleanId) != null) {
            return false;
        }

        // Prevent duplicate emails
        if (studentDAO.findByEmail(student.getEmail()) != null) {
            return false;
        }

        student.setCollegeId(cleanId);
        // Securely hash password with SHA-256 (never store plaintext)
        if (student.getPasswordHash() != null && !student.getPasswordHash().isEmpty()) {
            student.setPasswordHash(PasswordUtil.hash(student.getPasswordHash()));
        }
        // Status defaults to 'Not Verified' until reviewed by Admin
        if (student.getStatus() == null || student.getStatus().isEmpty()) {
            student.setStatus("Not Verified");
        }

        return studentDAO.insert(student);
    }
}
