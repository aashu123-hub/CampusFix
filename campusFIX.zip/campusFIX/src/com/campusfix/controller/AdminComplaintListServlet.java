package com.campusfix.controller;

import com.campusfix.model.Complaint;
import com.campusfix.service.ComplaintService;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

/**
 * Controller to fetch all complaints for review by Admin.
 */
@WebServlet(name = "AdminComplaintListServlet", urlPatterns = {"/admin/complaint/list", "/api/admin/complaints"})
public class AdminComplaintListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final ComplaintService complaintService = new ComplaintService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        resp.setContentType("application/json;charset=UTF-8");

        if (!"admin".equals(role)) {
            resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
            resp.getWriter().write(JsonUtil.errorResponse("Access denied: Administrative privileges required."));
            return;
        }

        List<Complaint> list = complaintService.getAllComplaints();
        resp.getWriter().write(JsonUtil.complaintsListToJson(list));
    }
}
