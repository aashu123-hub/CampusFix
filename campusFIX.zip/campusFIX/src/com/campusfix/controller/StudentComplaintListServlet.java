package com.campusfix.controller;

import com.campusfix.model.Complaint;
import com.campusfix.model.Student;
import com.campusfix.service.ComplaintService;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

/**
 * Controller to fetch list of complaints for currently authenticated student.
 */
@WebServlet(name = "StudentComplaintListServlet", urlPatterns = {"/student/complaint/list", "/api/student/complaints"})
public class StudentComplaintListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final ComplaintService complaintService = new ComplaintService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        Student student = (session != null) ? (Student) session.getAttribute("user") : null;

        resp.setContentType("application/json;charset=UTF-8");

        if (student == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            resp.getWriter().write(JsonUtil.errorResponse("Authentication required."));
            return;
        }

        List<Complaint> list = complaintService.getComplaintsForStudent(student.getCollegeId());
        resp.getWriter().write(JsonUtil.complaintsListToJson(list));
    }
}
