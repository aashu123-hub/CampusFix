package com.campusfix.controller;

import com.campusfix.model.Student;
import com.campusfix.service.ComplaintService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Map;

/**
 * Controller providing KPI statistics for Student and Admin Dashboards.
 */
@WebServlet(name = "DashboardStatsServlet", urlPatterns = {"/api/stats"})
public class DashboardStatsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final ComplaintService complaintService = new ComplaintService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        resp.setContentType("application/json;charset=UTF-8");

        String studentCollegeId = null;
        if ("student".equals(role)) {
            Student student = (Student) session.getAttribute("user");
            if (student != null) {
                studentCollegeId = student.getCollegeId();
            }
        }

        Map<String, Integer> stats = complaintService.getStats(studentCollegeId);

        StringBuilder sb = new StringBuilder("{");
        sb.append("\"total\":").append(stats.getOrDefault("total", 0)).append(",");
        sb.append("\"pending\":").append(stats.getOrDefault("pending", 0)).append(",");
        sb.append("\"in_progress\":").append(stats.getOrDefault("in_progress", 0)).append(",");
        sb.append("\"resolved\":").append(stats.getOrDefault("resolved", 0));
        sb.append("}");

        resp.getWriter().write(sb.toString());
    }
}
