package com.campusfix.controller;

import com.campusfix.model.Complaint;
import com.campusfix.model.Student;
import com.campusfix.service.ComplaintService;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Controller to fetch complaint details and timeline.
 * Preserves admin session role when admin inspects a student's complaint timeline.
 */
@WebServlet(name = "ComplaintDetailServlet", urlPatterns = {"/complaint/detail", "/api/complaint/detail"})
public class ComplaintDetailServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final ComplaintService complaintService = new ComplaintService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String complaintId = req.getParameter("id");

        resp.setContentType("application/json;charset=UTF-8");

        if (complaintId == null || complaintId.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write(JsonUtil.errorResponse("Complaint ID is required."));
            return;
        }

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("role") == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            resp.getWriter().write(JsonUtil.errorResponse("Authentication required to view complaint details."));
            return;
        }

        String role = (String) session.getAttribute("role");
        Complaint complaint = complaintService.getComplaintWithTimeline(complaintId.trim());

        if (complaint == null) {
            resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
            resp.getWriter().write(JsonUtil.errorResponse("Complaint #" + complaintId + " could not be found."));
            return;
        }

        // Role-Based Authorization
        if ("student".equals(role)) {
            Student student = (Student) session.getAttribute("user");
            String sessionCollegeId = (student != null) ? student.getCollegeId() : (String) session.getAttribute("college_id");
            if (sessionCollegeId == null || !sessionCollegeId.equalsIgnoreCase(complaint.getStudentCollegeId())) {
                resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
                resp.getWriter().write(JsonUtil.errorResponse("403 Forbidden: Under institutional privacy regulations, students can only inspect their own complaints."));
                return;
            }

            // Keep student-visible remarks separate from internal administrative notes
            if (complaint.getRemarks() != null && complaint.getRemarks().toUpperCase().startsWith("[INTERNAL]")) {
                complaint.setRemarks("Under review by college administration.");
            }
        }
        // If role is "admin", viewing timeline is permitted and session remains 100% admin

        resp.getWriter().write(JsonUtil.successResponse("Complaint found", JsonUtil.complaintToJson(complaint)));
    }
}
