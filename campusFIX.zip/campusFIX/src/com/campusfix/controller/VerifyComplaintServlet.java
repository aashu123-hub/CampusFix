package com.campusfix.controller;

import com.campusfix.service.ComplaintService;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Controller for Admin to mark a complaint as Genuine or Not Genuine.
 */
@WebServlet(name = "VerifyComplaintServlet", urlPatterns = {"/admin/complaint/verify", "/api/admin/complaint/verify"})
public class VerifyComplaintServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final ComplaintService complaintService = new ComplaintService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        resp.setContentType("application/json;charset=UTF-8");

        if (!"admin".equals(role)) {
            resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
            resp.getWriter().write(JsonUtil.errorResponse("Administrative privileges required."));
            return;
        }

        String complaintId = req.getParameter("complaint_id");
        String action = req.getParameter("action"); // 'genuine' | 'reject'
        String reason = req.getParameter("reason");

        if (complaintId == null || action == null) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write(JsonUtil.errorResponse("Missing required parameters."));
            return;
        }

        boolean isGenuine = "genuine".equalsIgnoreCase(action);
        boolean updated = complaintService.verifyComplaint(complaintId.trim(), isGenuine, reason);

        if (updated) {
            resp.getWriter().write(JsonUtil.successResponse("Complaint verification status updated", null));
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write(JsonUtil.errorResponse("Failed to update complaint verification status."));
        }
    }
}
