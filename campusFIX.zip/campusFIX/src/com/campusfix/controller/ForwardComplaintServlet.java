package com.campusfix.controller;

import com.campusfix.service.ComplaintService;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Controller for Admin to forward a complaint to a specialized operational department.
 */
@WebServlet(name = "ForwardComplaintServlet", urlPatterns = {"/admin/complaint/forward", "/api/admin/complaint/forward"})
public class ForwardComplaintServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final ComplaintService complaintService = new ComplaintService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        resp.setContentType("application/json;charset=UTF-8");

        if (!"admin".equals(role)) {
            resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
            resp.getWriter().write(JsonUtil.errorResponse("Administrative privileges required."));
            return;
        }

        String complaintId = req.getParameter("complaint_id");
        String department = req.getParameter("department");
        String tenure = req.getParameter("tenure");
        String remarks = req.getParameter("remarks");

        if (complaintId == null || department == null) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write(JsonUtil.errorResponse("Complaint ID and department are required."));
            return;
        }

        boolean success = complaintService.forwardComplaint(complaintId.trim(), department.trim(), tenure != null ? tenure : "3 Days", remarks);

        if (success) {
            resp.getWriter().write(JsonUtil.successResponse("Complaint forwarded to " + department + " successfully", null));
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write(JsonUtil.errorResponse("Failed to forward complaint."));
        }
    }
}
