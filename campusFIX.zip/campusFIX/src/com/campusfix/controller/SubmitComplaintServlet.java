package com.campusfix.controller;

import com.campusfix.model.Complaint;
import com.campusfix.model.Student;
import com.campusfix.service.ComplaintService;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Controller for students to submit complaints.
 */
@WebServlet(name = "SubmitComplaintServlet", urlPatterns = {"/student/complaint/submit", "/api/student/complaint/submit"})
public class SubmitComplaintServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final ComplaintService complaintService = new ComplaintService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        Student student = (session != null) ? (Student) session.getAttribute("user") : null;

        boolean isJson = "application/json".equalsIgnoreCase(req.getContentType()) ||
                         (req.getHeader("Accept") != null && req.getHeader("Accept").contains("application/json"));

        resp.setContentType("application/json;charset=UTF-8");

        if (student == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            resp.getWriter().write(JsonUtil.errorResponse("Please log in as a student to submit a complaint."));
            return;
        }

        String category = req.getParameter("category");
        String location = req.getParameter("location");
        String description = req.getParameter("description");
        String priority = req.getParameter("priority");
        String imageUrl = req.getParameter("image_url");

        if (category == null || category.trim().isEmpty() ||
            location == null || location.trim().isEmpty() ||
            description == null || description.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write(JsonUtil.errorResponse("Category, location, and description are required fields."));
            return;
        }

        if (description.trim().length() < 10) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write(JsonUtil.errorResponse("Description must be at least 10 characters long."));
            return;
        }

        // Duplicate Submission Prevention: throttle rapid duplicate submits from the same session
        long currentTime = System.currentTimeMillis();
        Long lastSubmitTime = (Long) session.getAttribute("last_complaint_submit_time");
        String lastSubmitPayload = (String) session.getAttribute("last_complaint_submit_payload");
        String currentPayload = category.trim() + "|" + location.trim() + "|" + description.trim();

        if (lastSubmitTime != null && (currentTime - lastSubmitTime < 5000) && currentPayload.equals(lastSubmitPayload)) {
            resp.setStatus(429);
            resp.getWriter().write(JsonUtil.errorResponse("Duplicate submission detected. Please wait a few seconds before submitting again."));
            return;
        }
        session.setAttribute("last_complaint_submit_time", currentTime);
        session.setAttribute("last_complaint_submit_payload", currentPayload);

        String cleanPriority = "Medium";
        if ("Low".equalsIgnoreCase(priority) || "High".equalsIgnoreCase(priority)) {
            cleanPriority = priority.substring(0, 1).toUpperCase() + priority.substring(1).toLowerCase();
        }

        Complaint complaint = new Complaint();
        complaint.setStudentCollegeId(student.getCollegeId());
        complaint.setStudentName(student.getFullName());
        complaint.setStudentDept(student.getDepartment());
        complaint.setCategory(category.trim());
        complaint.setLocation(location.trim());
        complaint.setDescription(description.trim());
        complaint.setPriority(cleanPriority);
        complaint.setImageUrl(imageUrl != null ? imageUrl.trim() : null);

        Complaint saved = complaintService.submitComplaint(complaint);

        if (saved != null) {
            if (isJson) {
                resp.getWriter().write(JsonUtil.successResponse("Complaint registered successfully", JsonUtil.complaintToJson(saved)));
            } else {
                resp.sendRedirect(req.getContextPath() + "/student/complaint-details.html?id=" + saved.getComplaintId());
            }
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write(JsonUtil.errorResponse("Failed to register complaint in database."));
        }
    }
}
