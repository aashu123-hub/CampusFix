package com.campusfix.controller;

import com.campusfix.model.Student;
import com.campusfix.service.AdminService;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

/**
 * Controller for Admin to verify student enrollments or list student directory.
 */
@WebServlet(name = "StudentVerifyServlet", urlPatterns = {"/admin/student/verify", "/api/admin/students"})
public class StudentVerifyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final AdminService adminService = new AdminService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        resp.setContentType("application/json;charset=UTF-8");

        if (!"admin".equals(role)) {
            resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
            resp.getWriter().write(JsonUtil.errorResponse("Administrative privileges required."));
            return;
        }

        String query = req.getParameter("q");
        List<Student> list = (query != null && !query.trim().isEmpty())
                ? adminService.searchStudents(query.trim())
                : adminService.getAllStudents();

        resp.getWriter().write(JsonUtil.studentsListToJson(list));
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        resp.setContentType("application/json;charset=UTF-8");

        if (!"admin".equals(role)) {
            resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
            resp.getWriter().write(JsonUtil.errorResponse("Administrative privileges required."));
            return;
        }

        String collegeId = req.getParameter("college_id");
        String status = req.getParameter("status"); // 'Verified' | 'Not Verified'

        if (collegeId == null || status == null) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write(JsonUtil.errorResponse("College ID and status are required."));
            return;
        }

        boolean success = adminService.updateStudentVerification(collegeId.trim(), status.trim());

        if (success) {
            resp.getWriter().write(JsonUtil.successResponse("Student verification status set to " + status, null));
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write(JsonUtil.errorResponse("Failed to update student verification status."));
        }
    }
}
