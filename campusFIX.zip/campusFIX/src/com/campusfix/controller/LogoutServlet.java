package com.campusfix.controller;

import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Controller to terminate active sessions and return to the login-selection page.
 */
@WebServlet(name = "LogoutServlet", urlPatterns = {"/logout", "/api/logout"})
public class LogoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processLogout(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processLogout(req, resp);
    }

    private void processLogout(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        if (session != null) {
            session.invalidate();
        }

        boolean isJson = "application/json".equalsIgnoreCase(req.getContentType()) ||
                         (req.getHeader("Accept") != null && req.getHeader("Accept").contains("application/json"));

        if (isJson) {
            resp.setContentType("application/json;charset=UTF-8");
            resp.getWriter().write(JsonUtil.successResponse("Session invalidated", null));
        } else {
            resp.sendRedirect(req.getContextPath() + "/index.html");
        }
    }
}
