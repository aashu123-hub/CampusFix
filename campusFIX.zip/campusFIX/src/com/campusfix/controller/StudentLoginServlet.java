package com.campusfix.controller;

import com.campusfix.model.Student;
import com.campusfix.service.AuthService;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Controller for Student Authentication.
 */
@WebServlet(name = "StudentLoginServlet", urlPatterns = {"/student/login", "/api/student/login"})
public class StudentLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final AuthService authService = new AuthService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String collegeId = req.getParameter("college_id");
        String password = req.getParameter("password");

        Student student = authService.authenticateStudent(collegeId, password);

        boolean isJson = "application/json".equalsIgnoreCase(req.getContentType()) ||
                         (req.getHeader("Accept") != null && req.getHeader("Accept").contains("application/json"));

        resp.setContentType("application/json;charset=UTF-8");

        if (student != null) {
            // Prevent Session Fixation: Invalidate old session before creating a new authenticated session
            HttpSession oldSession = req.getSession(false);
            if (oldSession != null) {
                oldSession.invalidate();
            }
            HttpSession session = req.getSession(true);
            session.setAttribute("role", "student");
            session.setAttribute("user", student);
            session.setAttribute("college_id", student.getCollegeId());

            if (isJson) {
                resp.getWriter().write(JsonUtil.successResponse("Login successful", JsonUtil.studentToJson(student)));
            } else {
                resp.sendRedirect(req.getContextPath() + "/student/dashboard.html");
            }
        } else {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            if (isJson) {
                resp.getWriter().write(JsonUtil.errorResponse("Invalid College Unique ID or Password."));
            } else {
                req.setAttribute("error", "Invalid College Unique ID or Password.");
                resp.sendRedirect(req.getContextPath() + "/student/login.html?error=invalid_credentials");
            }
        }
    }
}
