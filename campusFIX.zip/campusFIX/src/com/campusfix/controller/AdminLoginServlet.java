package com.campusfix.controller;

import com.campusfix.model.Admin;
import com.campusfix.service.AuthService;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Controller for Admin Authentication.
 */
@WebServlet(name = "AdminLoginServlet", urlPatterns = {"/admin/login", "/api/admin/login"})
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final AuthService authService = new AuthService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String adminId = req.getParameter("admin_id");
        String password = req.getParameter("password");

        Admin admin = authService.authenticateAdmin(adminId, password);

        boolean isJson = "application/json".equalsIgnoreCase(req.getContentType()) ||
                         (req.getHeader("Accept") != null && req.getHeader("Accept").contains("application/json"));

        resp.setContentType("application/json;charset=UTF-8");

        if (admin != null) {
            // Prevent Session Fixation: Invalidate old session before creating a new authenticated session
            HttpSession oldSession = req.getSession(false);
            if (oldSession != null) {
                oldSession.invalidate();
            }
            HttpSession session = req.getSession(true);
            session.setAttribute("role", "admin");
            session.setAttribute("user", admin);
            session.setAttribute("admin_id", admin.getAdminId());

            if (isJson) {
                resp.getWriter().write(JsonUtil.successResponse("Admin authenticated successfully", JsonUtil.adminToJson(admin)));
            } else {
                resp.sendRedirect(req.getContextPath() + "/admin/dashboard.html");
            }
        } else {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            if (isJson) {
                resp.getWriter().write(JsonUtil.errorResponse("Invalid Administrator credentials. Default is admin / admin123."));
            } else {
                resp.sendRedirect(req.getContextPath() + "/admin/login.html?error=invalid_credentials");
            }
        }
    }
}
