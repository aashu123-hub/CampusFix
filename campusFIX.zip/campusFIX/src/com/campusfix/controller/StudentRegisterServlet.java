package com.campusfix.controller;

import com.campusfix.model.Student;
import com.campusfix.service.AuthService;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Controller for Student Registration.
 */
@WebServlet(name = "StudentRegisterServlet", urlPatterns = {"/student/register", "/api/student/register"})
public class StudentRegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final AuthService authService = new AuthService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String collegeId = req.getParameter("college_id");
        String fullName = req.getParameter("full_name");
        String email = req.getParameter("email");
        String mobile = req.getParameter("mobile");
        String department = req.getParameter("department");
        String course = req.getParameter("course");
        String year = req.getParameter("year");
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirm_password");

        boolean isJson = "application/json".equalsIgnoreCase(req.getContentType()) ||
                         (req.getHeader("Accept") != null && req.getHeader("Accept").contains("application/json"));

        resp.setContentType("application/json;charset=UTF-8");

        // Basic validations
        if (collegeId == null || !collegeId.trim().toUpperCase().startsWith("BIET")) {
            respondError(resp, isJson, "College Unique ID must begin with institutional prefix 'BIET'.", req);
            return;
        }

        if (password == null || password.length() < 6) {
            respondError(resp, isJson, "Password must be at least 6 characters long.", req);
            return;
        }

        if (!password.equals(confirmPassword)) {
            respondError(resp, isJson, "Passwords do not match.", req);
            return;
        }

        Student student = new Student(
            collegeId.trim().toUpperCase(),
            fullName != null ? fullName.trim() : "",
            email != null ? email.trim().toLowerCase() : "",
            mobile != null ? mobile.trim() : "",
            department != null ? department.trim() : "CSE",
            course != null ? course.trim() : "B.Tech",
            year != null ? year.trim() : "1st Year",
            password.trim(),
            "Not Verified"
        );

        boolean registered = authService.registerStudent(student);

        if (registered) {
            // Auto-login registered student with Session Fixation Protection
            HttpSession oldSession = req.getSession(false);
            if (oldSession != null) {
                oldSession.invalidate();
            }
            HttpSession session = req.getSession(true);
            session.setAttribute("role", "student");
            session.setAttribute("user", student);
            session.setAttribute("college_id", student.getCollegeId());

            if (isJson) {
                resp.getWriter().write(JsonUtil.successResponse("Registration successful", JsonUtil.studentToJson(student)));
            } else {
                resp.sendRedirect(req.getContextPath() + "/student/dashboard.html?registered=true");
            }
        } else {
            respondError(resp, isJson, "Registration failed. College ID or Email may already be registered.", req);
        }
    }

    private void respondError(HttpServletResponse resp, boolean isJson, String message, HttpServletRequest req) throws IOException {
        resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        if (isJson) {
            resp.getWriter().write(JsonUtil.errorResponse(message));
        } else {
            resp.sendRedirect(req.getContextPath() + "/student/register.html?error=" + java.net.URLEncoder.encode(message, "UTF-8"));
        }
    }
}
