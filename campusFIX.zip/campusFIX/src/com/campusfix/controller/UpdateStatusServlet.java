package com.campusfix.controller;

import com.campusfix.service.ComplaintService;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Date;

/**
 * Controller for Admin to update lifecycle status and message on a complaint.
 */
@WebServlet(name = "UpdateStatusServlet", urlPatterns = {"/admin/complaint/update-status", "/api/admin/complaint/update-status"})
public class UpdateStatusServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final ComplaintService complaintService = new ComplaintService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        resp.setContentType("application/json;charset=UTF-8");

        if (!"admin".equals(role)) {
            resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
            resp.getWriter().write(JsonUtil.errorResponse("Administrative privileges required."));
            return;
        }

        String complaintId = req.getParameter("complaint_id");
        String status = req.getParameter("status");
        String dateStr = req.getParameter("expected_date");
        String message = req.getParameter("message");

        if (complaintId == null || status == null) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write(JsonUtil.errorResponse("Complaint ID and status are required."));
            return;
        }

        Date expectedDate = null;
        if (dateStr != null && !dateStr.trim().isEmpty()) {
            try {
                expectedDate = Date.valueOf(dateStr.trim());
            } catch (IllegalArgumentException ignored) {
            }
        }

        boolean success = complaintService.updateComplaintStatus(complaintId.trim(), status.trim(), expectedDate, message);

        if (success) {
            resp.getWriter().write(JsonUtil.successResponse("Complaint status updated to " + status, null));
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write(JsonUtil.errorResponse("Failed to update complaint status."));
        }
    }
}
