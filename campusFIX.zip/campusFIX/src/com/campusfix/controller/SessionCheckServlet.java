package com.campusfix.controller;

import com.campusfix.model.Admin;
import com.campusfix.model.Student;
import com.campusfix.util.JsonUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Controller to check current active session state for frontend authentication verification.
 */
@WebServlet(name = "SessionCheckServlet", urlPatterns = {"/api/session"})
public class SessionCheckServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);

        resp.setContentType("application/json;charset=UTF-8");

        if (session == null || session.getAttribute("role") == null) {
            resp.getWriter().write("{\"authenticated\":false,\"role\":null,\"user\":null}");
            return;
        }

        String role = (String) session.getAttribute("role");
        Object userObj = session.getAttribute("user");
        String userJson = "null";

        if ("student".equals(role) && userObj instanceof Student) {
            userJson = JsonUtil.studentToJson((Student) userObj);
        } else if ("admin".equals(role) && userObj instanceof Admin) {
            userJson = JsonUtil.adminToJson((Admin) userObj);
        }

        resp.getWriter().write("{\"authenticated\":true,\"role\":\"" + JsonUtil.escape(role) + "\",\"user\":" + userJson + "}");
    }
}
